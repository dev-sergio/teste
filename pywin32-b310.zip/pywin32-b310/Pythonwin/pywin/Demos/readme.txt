For a good example of all the demos, start Pythonwin, and run the
script guidemo.py
