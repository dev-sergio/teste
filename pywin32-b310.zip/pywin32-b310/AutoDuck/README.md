Just run [make.py](./make.py) to build the documentation.

Main focus these days is on the .chm file - a single .chm
provides the best documentation solution.  We don't even
build a .hlp file anymore.

pywin32-document.xml provides the front-page for the docs.
