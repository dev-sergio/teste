select nome as OBJETO, tp as PRODTIPO from impactCatalog a where dtgen is not null and dtgen>versaoatual
--and tp=9
