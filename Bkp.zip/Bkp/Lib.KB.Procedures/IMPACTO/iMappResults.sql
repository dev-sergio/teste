--drop proc #mapp_results
--go

create proc #mapp_results as
begin
  
  if exists ( select 1 from syscolumns a, sysobjects b where a.name='expand' and a.id=b.id and b.name='tb_variaveis' )
    begin
      alter table tb_variaveis drop column ate
      alter table tb_variaveis drop column expand
      alter table tb_ioarea drop column expand
      alter table tb_jclstep drop column expand
    end
  
  alter table tb_variaveis add ate integer
  alter table tb_variaveis add expand integer
  alter table tb_ioarea add expand integer
  alter table tb_jclstep add expand integer
  
  update a set ate=(select min(LINHAEXP)-1 from TB_VARIAVEIS b where b.PROGRAMA=a.PROGRAMA and b.LINHAEXP>a.LINHAEXP and b.NIVEL<=a.nivel)
  from TB_VARIAVEIS a where a.tipo='G' and a.area not in ('2') and ate is null
  update a set ate=(select expandido from TB_PROGRAMAS b where b.nome=a.PROGRAMA)
  from TB_VARIAVEIS a where a.tipo='G' and a.area not in ('2') and ate is null
  update tb_ioarea set expand=null where expand is not null
  update tb_jclstep set expand=null where expand is not null
  
  if exists ( select 1 from sysobjects where name='impactResults' )
    drop table impactResults
  
  create table impactResults (
    id integer,
    tpImpact varchar(20),
    tp integer,
    programa varchar(255),
    fonte  varchar(255),
    nome   varchar(255),
    redef  varchar(255),
    ofs    int,
	nro1   int,
	nro2   int,
    tipo   char(1),
    form   char(1),
    tam    int,
    fmt    varchar(255),
    linexp integer,
    linate integer,
    linfon   integer,
    txt    varchar(255),
    dsc    varchar(4096),
    idimp  integer,
    linfiller integer,
    tamfiller integer,
    expand integer,
    altera varchar(255),
    value varchar(255),
    linpic int,
    linval int,
    dscalter varchar(2048)
  )
  create index ix1 on impactResults ( programa, linexp )
  create index ix2 on impactResults ( programa, nome )
  
  insert into impactResults
  select a.seq, '', a.tipo, b.programa, b.fonte, objeto, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, classe, '', a.ID, 0, 0, 0
         ,null,null,null,null,null 
  from TABIMPACT a, TB_VARIAVEIS b where a.tipo in (99, 97) and a.nivel<999 and b.fonte=a.pai and b.nome=a.OBJETO and b.area not in ( '2', 'a' ) and precisao=0
  and a.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )
  
  insert into impactResults
  select a.id, '', a.tp, b.programa, b.fonte, b.nome, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, a.txt, '', a.idimp, 0, 0, 0
         ,null,null,null,null,null 
  from impactResults a, TB_VARIAVEIS b where a.redef<>''
  and b.programa=a.programa and b.nome=a.redef
  and 1 not in ( select 1 from impactResults x where x.programa=a.programa and x.nome=b.nome )
  and b.nome<>'filler' and b.area not in ( '2', 'a' ) and precisao=0
  group by a.id, a.idimp, a.tp, b.programa, b.fonte, b.nome, b.redefines, b.tipo, b.formato, b.tamanho, b.MASKEDIT, b.LINHAEXP, b.LINHAFONTE, b.offset, txt, nro1, nro2
  
  insert into impactResults
  select a.id, '', a.tp, b.programa, b.fonte, b.nome, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, txt, '', a.idimp, 0, 0, 0
         ,null,null,null,null,null 
  from impactResults a, TB_VARIAVEIS b where 
  b.programa=a.programa and b.REDEFINES=a.nome
  and 1 not in ( select 1 from impactResults x where x.programa=a.programa and x.nome=b.nome )
  and b.nome<>'filler' and b.area not in ( '2', 'a' ) and precisao=0
  group by a.id, a.idimp, a.tp, b.programa, b.fonte, b.nome, b.redefines, b.tipo, b.formato, b.tamanho, b.MASKEDIT, b.LINHAEXP, b.LINHAFONTE, b.offset, txt, nro1, nro2

  insert into impactResults
  select distinct a.id, '', a.tp, b.programa, b.fonte, b.nome, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, 'NUMBASE', '', a.idimp, 0, 0, 0
         ,null,null,null,null,null 
  from impactResults a, TB_VARIAVEIS b where a.tp=99 and a.tipo='G' and b.programa=a.programa and b.OFFSET=a.ofs
  and b.TAMANHO in ( 8, 9 )
  and b.nome<>'filler' and b.area not in ( '2', 'a' ) and precisao=0
  and b.nome not like '%-DT%'
  and b.nome not like '%-QT%'
  and b.nome not like '%-DAT%'
  and b.nome not like '%-QUA%'
  and b.nome not like '%-TOT%'
  --and b.LINHAEXP=a.linexp+1
  and 1 not in ( select 1 from impactResults x where x.programa=a.programa and x.nome=b.nome )
  
  insert into impactResults
  select distinct a.id, '', a.tp, b.programa, b.fonte, b.nome, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, 'BASEFIL', '', a.idimp, 0, 0, 0
         ,null,null,null,null,null 
  from impactResults a, TB_VARIAVEIS b where a.tp=99 and a.tipo='G' and b.programa=a.programa and b.OFFSET=a.ofs
  and b.TAMANHO in ( 12, 13 )
  and b.nome<>'filler' and b.area not in ( '2', 'a' ) and precisao=0
  and 1 not in ( select 1 from impactResults x where x.programa=a.programa and x.nome=b.nome )

  insert into impactResults
  select distinct x.id, '', x.tp, f.programa, f.fonte, f.nome, f.redefines, f.OFFSET, nro1, nro2, f.tipo, f.formato, f.tamanho, f.MASKEDIT, f.LINHAEXP, 0, f.LINHAFONTE, x.tpImpact, '', x.idimp, 0, 0, 0
         ,null,null,null,null,null 
  --select DISTINCT e.nome, f.nome 
    from TB_IOAREA a, TB_VARIAVEIS B, TB_VARIAVEIS c, TB_VARIAVEIS d, TB_VARIAVEIS e, impactResults x, TB_VARIAVEIS f 
   where a.cobname='MAPAREA'
     and b.PROGRAMA=a.PROGRAMA and b.nome=a.REGISTRO
	 and c.programa=b.PROGRAMA and c.OFFSET=b.OFFSET and c.fonte<>b.fonte
	 and d.programa=c.PROGRAMA and d.LINHAEXP between c.LINHAEXP and c.ate and d.Occ1>0
	 and e.PROGRAMA=d.PROGRAMA and e.OFFSET>=d.OFFSET and e.OFFSET<d.OFFSET+d.TAMANHO and e.nome <>'FILLER'
	 and x.programa=e.PROGRAMA and x.linexp=e.LINHAEXP 
	 and f.PROGRAMA=e.PROGRAMA and f.OFFSET>=d.OFFSET and f.OFFSET<d.OFFSET+d.TAMANHOFIS
	 and (f.OFFSET-d.OFFSET)%d.TAMANHO = e.OFFSET-d.OFFSET and f.TAMANHOFIS=e.TAMANHOFIS
     and 1 not in ( select 1 from impactResults x where x.programa=f.programa and x.nome=f.nome )

  update a set tpimpact='TIPO', expand=0 from impactResults a where a.tp=99 and a.tipo='9' and a.form not in ( 'b', 'p' ) and txt not like '%DAC%' AND txt not like '%CPF%'
  update a set tpimpact='TAMBIN', expand=TAMANHO-TAMANHOFIS
  --select b.MASKEDIT, b.FORMATO, TAMANHO-TAMANHOFIS 
  from impactResults a, TB_VARIAVEIS b where a.tp=99 and a.tipo='9' and a.form in ( 'b' ) and txt not like '%DAC%' AND txt not like '%CPF%'
  and b.PROGRAMA=a.programa and b.LINHAEXP=a.linexp
  update a set tpimpact='TAMPACK', expand=TAMANHO-TAMANHOFIS
  --select b.MASKEDIT, b.FORMATO, TAMANHO-TAMANHOFIS 
  from impactResults a, TB_VARIAVEIS b where a.tp=99 and a.tipo='9' and a.form in ( 'p' ) and txt not like '%DAC%' AND txt not like '%CPF%'
  and b.PROGRAMA=a.programa and b.LINHAEXP=a.linexp

  insert into impactResults
  select distinct a.id, '', 97, b.programa, b.fonte, b.nome, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, '', '', a.idimp, 0, 0, 0
         ,null,null,null,null,null 
    from impactResults a, TB_VARIAVEIS b
   where a.tp=99 and b.programa=a.programa and a.linexp between b.LINHAEXP and b.ate
  and 1 not in ( select 1 from impactResults x where x.programa=a.programa and x.nome=b.nome )
  and ( b.nome<>'FILLER' or b.REDEFINES<>'' )

  insert into impactResults
  select a.id, '', a.tp, b.programa, b.fonte, b.nome, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, a.txt, '', a.idimp, 0, 0, 0
         ,null,null,null,null,null 
  from impactResults a, TB_VARIAVEIS b where a.redef<>''
  and b.programa=a.programa and b.nome=a.redef
  and 1 not in ( select 1 from impactResults x where x.programa=a.programa and x.nome=b.nome )
  and b.nome<>'filler' and b.area not in ( '2', 'a' ) and precisao=0
  group by a.id, a.idimp, a.tp, b.programa, b.fonte, b.nome, b.redefines, b.tipo, b.formato, b.tamanho, b.MASKEDIT, b.LINHAEXP, b.LINHAFONTE, b.offset, txt, nro1, nro2
  
  insert into impactResults
  select a.id, '', a.tp, b.programa, b.fonte, b.nome, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, txt, '', a.idimp, 0, 0, 0
         ,null,null,null,null,null 
  from impactResults a, TB_VARIAVEIS b where 
  b.programa=a.programa and b.REDEFINES=a.nome
  and 1 not in ( select 1 from impactResults x where x.programa=a.programa and x.nome=b.nome )
  and b.nome<>'filler' and b.area not in ( '2', 'a' ) and precisao=0
  group by a.id, a.idimp, a.tp, b.programa, b.fonte, b.nome, b.redefines, b.tipo, b.formato, b.tamanho, b.MASKEDIT, b.LINHAEXP, b.LINHAFONTE, b.offset, txt, nro1, nro2

  insert into impactResults
  select distinct a.id, '', a.tp, b.programa, b.fonte, b.nome, b.redefines, b.OFFSET, nro1, nro2, b.tipo, b.formato, b.tamanho, MASKEDIT, LINHAEXP, 0, LINHAFONTE, txt, '', a.idimp, 0, 0, 0
         ,null,null,null,null,null 
    from impactResults a, TB_VARVAR c, TB_VARIAVEIS b where a.programa=c.PROGRAMA and a.nome=vr1 and c.ACAO='STRING'
     and 1 in ( select 1 from TB_IOAREA x where x.programa=c.PROGRAMA and x.REGISTRO=vr2 )
	 and b.programa=c.PROGRAMA and b.nome=c.vr2
     and 1 not in ( select 1 from impactResults x where x.programa=a.programa and x.nome=b.nome )

  update a set linate=c.LINHAEXP-1 
  from impactResults a, TB_VARIAVEIS b, TB_VARIAVEIS c where --a.programa='DD320' and 
  a.tipo='G' and linate=0
  and b.programa=a.programa and b.LINHAEXP=a.linexp and c.PROGRAMA=a.programa and c.linhaexp>b.linhaexp and c.NIVEL<=b.NIVEL
  and c.LINHAEXP=(select min(linhaexp) from TB_VARIAVEIS c where c.PROGRAMA=a.programa and c.linhaexp>b.linhaexp and c.NIVEL<=b.NIVEL)

  --select * from impactResults a where a.tipo='G' and a.linate>0
  update a set linate=b.EXPANDIDO from impactResults a, TB_PROGRAMAS b where a.tipo='G' and a.linate=0 and b.nome=a.programa

  insert into impactResults
  select distinct min(a.seq), '', a.tipo, b.programa, '', objeto, '', 0, nro1, nro2, '', '', 0, '', 0, 0, 0, classe, '', min(a.ID), 0, 0, 0
         ,null,null,null,null,null 
  from TABIMPACT a, TB_ARQUIVOS b where a.tipo not in (97,99) and b.programa=a.pai and b.ddname=a.OBJETO 
  and a.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )
  and 1 not in ( select 1 from TB_VARIAVEIS where programa=b.programa and nome=b.DDNAME and area='l' )
  group by a.tipo, b.programa, objeto, classe, nro1, nro2

  insert into impactResults
  select distinct min(a.seq), '', a.tipo, b.programa, '', objeto, '', 0, nro1, nro2, '', '', 0, '', 0, 0, 0, classe, '', min(a.ID), 0, 0, 0
         ,null,null,null,null,null 
  from TABIMPACT a, TB_ARQUIVOS b where a.tipo not in (97,99) and a.pai='ONLINE' and b.ddname=a.OBJETO and b.tipo in ( 4,128  )
  and a.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )
  and 1 not in ( select 1 from TB_VARIAVEIS where programa=b.programa and nome=b.DDNAME and area='l' )
  group by a.tipo, b.programa, objeto, classe, nro1, nro2
    
  insert into impactResults
  select a.seq, '', a.tipo, pai, '', objeto, '', nro1, nro1, nro2, '', '', nro2, '', 0, 0, 0, classe, '', a.ID, 0, 0, 0
         ,null,null,null,null,null 
  from TABIMPACT a where a.tipo not in (5, 9, 10, 93, 94, 95, 96, 97,99) 
  and 1 not in ( select 1 from impactResults x where x.programa=pai and x.nome=objeto )
  and a.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )
  
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tpImpact='' and a.tp in ( 97, 99 ) 
     and b.programa=a.programa and b.tp=99 and b.linexp between a.linexp and a.linate and b.tpImpact like 'TAM%'
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tpImpact='' and a.tp in ( 97, 99 ) 
     and b.programa=a.programa and b.tp=99 and b.linexp between a.linexp and a.linate and b.tpImpact='TIPO'
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tpImpact='' and a.tp in ( 97, 99 ) 
     and b.programa=a.programa and b.tp=99 and b.linexp between a.linexp and a.linate and b.tpImpact<>''
  
  update a set tpImpact=d.tpImpact from impactResults a, TB_IOAREA b, TB_IOAREA c, impactResults d where a.tpImpact='' and a.tp in ( 97, 99 ) 
     and b.programa=a.programa and b.REGISTRO=a.nome
     and c.programa=a.programa and c.DDNAME=b.DDNAME and c.REGISTRO<>b.REGISTRO
	 and d.programa=c.PROGRAMA and d.nome=c.REGISTRO and d.tpImpact<>''
  
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tp in ( 97, 99 ) and a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact like 'TAM%'
  while @@ROWCOUNT>0
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tp in ( 97, 99 ) and a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact like 'TAM%'
  
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tp in ( 97, 99 ) and a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact like 'TIPO%'
  while @@ROWCOUNT>0
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tp in ( 97, 99 ) and a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact like 'TIPO%'
  
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tp in ( 97, 99 ) and a.tpImpact='' and a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact<>''
  while @@ROWCOUNT>0
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tp in ( 97, 99 ) and a.tpImpact='' and a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact<>''
  
  update a set programa=E_GRPNAME, fonte=comando from impactResults a, MAPFIELD b where a.tp=1402 and E_MAPNAME=nome
  
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact like 'TAM%'
  while @@ROWCOUNT>0
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact like 'TAM%'
  
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact<>''
  while @@ROWCOUNT>0
  update a set tpImpact=b.tpImpact from impactResults a, impactResults b where a.tpImpact='' and a.idimp>0 and b.id=a.idimp and b.tpImpact<>''
  
  update a set dsc=b.texto from impactResults a, TABIMPACT b where a.tp=1105 and b.OBJETO=a.nome
  and b.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )

/*  
  insert into impactResults
  select distinct min(c.seq), tpImpact, c.tipo, b.programa, '', objeto, '', 0, '', '', 0, '', 0, 0, 0, classe, '', min(a.ID), 0, 0, 0
         ,null,null,null,null,null 
     from impactResults a, TB_IOAREA b, TABIMPACT c where a.tp in ( 97, 99 ) 
     and b.programa=a.programa and b.REGISTRO=a.nome and b.cobname='maparea'
	 and c.OBJETO=ddname
	group by c.tipo, b.PROGRAMA, objeto, classe, tpImpact
 */
  /*
  select a.nome, d.* from impactResults a, TB_VARIAVEIS b, TB_VARIAVEIS c, TB_IOAREA d where a.tp=99 and a.tpImpact like 'tam%'
  and b.PROGRAMA=a.programa and b.LINHAEXP=a.linexp
  and c.PROGRAMA=a.programa and b.OFFSET>c.OFFSET and b.OFFSET<c.OFFSET+c.TAMANHO and c.TIPO='G'
  and d.programa=c.PROGRAMA and d.REGISTRO=c.nome
  */

  --SELECT * FROM impactResults WHERE TP=97 AND tpImpact='CONTEM'
  
  update a set linfiller=b.LINHAEXP, tamfiller=b.TAMANHO from impactResults a, TB_VARIAVEIS b where a.tp=97
  and txt not like 'DAC%' and txt not like 'CPF%'
  and b.PROGRAMA=a.PROGRAMA and b.LINHAEXP between a.linexp and a.linate and b.nome like '%FILL%'
  and b.LINHAEXP in ( select max(linhaexp) from TB_VARIAVEIS c where c.programa=a.programa and c.LINHAEXP between a.linexp and a.linate and c.nome like '%FILL%' )
  
  update a set expand=( select sum(expand) from impactResults b where b.programa=a.programa and b.linexp between a.linexp and a.linate and b.expand>=0 and b.tp=99 and txt not like 'DAC%' and txt not like 'CPF%')
  from impactResults a where a.tp in ( 97, 99 ) and expand=0
  and 1 in ( select 1 from impactResults b where b.programa=a.programa and b.linexp between a.linexp and a.linate and b.expand is not null and expand>=0 and b.tp=99 
  and txt not like 'DAC%' and txt not like 'CPF%')

  update b set expand=a.expand from impactResults a, TB_VARIAVEIS b where a.tp in ( 97, 99 ) and ( a.expand>0 or tpImpact='TIPO' or tpImpact<>'' ) and b.PROGRAMA=a.programa and b.LINHAEXP=a.linexp 
  update b set expand=-abs(a.expand) from TB_VARIAVEIS a, TB_VARIAVEIS b where a.expand is not null and a.REDEFINES<>'' and b.PROGRAMA=a.PROGRAMA and b.nome=a.REDEFINES and b.expand is null
  update b set expand=-abs(a.expand) from TB_VARIAVEIS a, TB_VARIAVEIS b where a.expand is not null and a.REDEFINES<>'' and b.PROGRAMA=a.PROGRAMA and b.REDEFINES=a.nome and b.expand is null 
  update b set expand=-abs(a.expand) from TB_VARIAVEIS a, TB_VARIAVEIS b where a.expand is not null and a.area='f' and b.programa=a.PROGRAMA and b.OFFSET=a.OFFSET and b.nivel=1 and b.expand is null and b.area<>'2'
  
  update b set expand=abs(a.expand) from TB_VARIAVEIS a, TB_IOAREA b where a.expand is not null and b.programa=a.PROGRAMA and b.REGISTRO=a.nome and b.expand is null

  --SELECT * FROM TB_IOAREA WHERE expand=0
  update b set expand=a.expand from TB_IOAREA a, TB_JCLSTEP b where a.expand is not null
  and b.programa=a.PROGRAMA and b.DDNAME=a.DDNAME and b.DATASETNAME<>''

  declare @q int
  update b set expand=a.expand from TB_JCLSTEP a, TB_JCLSTEP b where a.expand is not null and b.DATASETNAME=a.DATASETNAME and b.expand is null and b.DATASETNAME<>''
  set @q = @@ROWCOUNT
  while @q>0
    begin
      set @q = 0
      UPDATE b set expand=a.expand from TB_JCLSTEP a, TB_JCLSTEP b where a.expand is not null and a.DUPARQ='S' and b.jcl=a.jcl and b.ORDEM=a.ORDEM and b.INPOUT in ( 'i','o' ) and b.DUPARQ='S' and b.expand is null and b.DATASETNAME<>''
      set @q = @q + @@ROWCOUNT
      UPDATE b set expand=a.expand from TB_JCLSTEP a, TB_JCLSTEP b where a.expand is not null and b.jcl=a.jcl and b.ORDEM=a.ORDEM and b.ddname=a.DDNAME and b.DATASETNAME<>'' and b.expand is null
      set @q = @q + @@ROWCOUNT
      update b set expand=a.expand from tb_jclstep a, tb_jclstep b where a.expand is not null and b.programa=a.PROGRAMA and b.DDNAME=a.DDNAME and b.expand is null and b.DATASETNAME<>''
  	     and 1 in ( select top 1 1 from TB_IOAREA x where x.programa=a.PROGRAMA and x.DDNAME=a.DDNAME )
      set @q = @q + @@ROWCOUNT
      update b set expand=a.expand from TB_JCLSTEP a, TB_JCLSTEP b where a.expand is not null and b.DATASETNAME=a.DATASETNAME and b.expand is null
      set @q = @q + @@ROWCOUNT
    end

  update b set expand=a.expand from TB_JCLSTEP a, tb_ioarea b where a.expand is not null and b.programa=a.programa and b.DDNAME=a.DDNAME and b.expand is null
  
  update b set expand=a.expand from TB_IOAREA a, TB_VARIAVEIS b where a.expand is not null and b.PROGRAMA=a.PROGRAMA and b.nome=a.REGISTRO and b.expand is null

  --select * from impactResults a, TB_IOAREA b where a.programa=b.PROGRAMA and a.nome=b.REGISTRO and b.COBNAME='maparea'
  --   and 1 not in (select 1 from MAPFIELD where E_MAPNAME=ddname )
  --select * from TB_JCLSTEP where acct='ikjeft01'

  insert into impactResults 
  select a.id, a.tpImpact, 96, a.programa, b.DDNAME, a.nome, a.redef, a.ofs, nro1, nro2, a.tipo, a.form, a.tam, a.fmt, a.linexp, a.linate, a.linfon, a.txt, a.dsc, a.idimp,
         a.linfiller, a.tamfiller, a.expand, null, null, null, null, null
  from impactResults a, TB_IOAREA b where a.programa=b.PROGRAMA and a.nome=b.REGISTRO 
  and b.COBNAME='linkage'

  insert into impactResults 
  select a.id, a.tpImpact, 14, a.programa, mfs, a.nome, modname, a.ofs, nro1, nro2, a.tipo, a.form, a.tam, a.fmt, a.linexp, a.linate, a.linfon, a.txt, a.dsc, a.idimp,
         0, 0, a.expand, null, null, null, null, null
    from impactResults a, imsacessos b where a.programa=b.programa and a.nome=b.buff and fonte='cbltdli' and modname<>''

  update a set nome='IMS-MSG', tp=93, redef=a.nome 
    from impactResults a, imsacessos b where a.programa=b.programa and a.nome=b.buff and fonte='cbltdli' and modname=''
  update a set tp=93, redef=nome, nome='IMS-OUT'
    from impactResults a where a.tp=96 and a.fonte like '$%zz' 

  delete a from impactResults a where a.tipo='G' and a.tp<>99
     and 1 not in ( select 1 from impactResults b where b.programa=a.programa and b.linexp>a.linexp and b.linexp<a.linate  )
     and 1 not in ( select 1 from TB_IOAREA b where b.programa=a.programa and b.REGISTRO=a.nome )

  if exists ( select 1 from sysobjects where name='impactCatalog' )
    drop table impactCatalog
  
  create table impactCatalog
  (
     sigla varchar(30),
     tp   int,
     tipo  varchar(30),
     nome  varchar(255),
	 ext    varchar(8),
     qtdref integer,
     qtdtip integer,
     qtdtam integer,
     tpImpacto varchar(255),
     linhas int,
     qtdlin int,
     qtdtel int,
     qtdarq int,
     grau char,
     pontos int,
     versaoimpacto date,
     versaoatual date,
     id integer,
     niv integer,
     qtdWrk integer,
     dscImp varchar(512),
	 dtgen datetime
  )
  
  create index ix1 on impactCatalog ( sigla, tp, nome )

  insert into impactCatalog
  select distinct rtrim(siglasis), 9, 'Programa', b.nome, b.ext, 0, 0, 0, '', 0, 0, 0, 0, '', 0, TMLOAD, tmload, null, null, null, null, null
    from impactResults a, TB_PROGRAMAS b
  where a.programa=b.nome and b.ext not in ('PSB', 'MFS', 'BMS' )
  
  insert into impactCatalog
  select distinct rtrim(siglasis), 14, 'Tela', b.nome, b.ext, 0, 0, 0, '', 0, 0, 0, 0, '', 0, tmload, tmload, null, null, null, null, null 
    from impactResults a, TB_PROGRAMAS b
  where a.programa=b.nome and b.ext in ('MFS', 'BMS' )
  
  insert into impactCatalog
  select distinct rtrim(siglasis), 7, (case when ext='jcl' then 'Procedure' else 'Job' end), b.nome, b.ext, 0, 0, 0, '', 0, 0, 0, 0, '', 0, TM, tm, null, null, null, null, null 
    from impactResults a, TB_rotinas b
  where a.nome=b.nome 
  
  insert into impactCatalog
  select distinct '', 10, 'Copybook', b.nome, b.ext, 0, 0, 0, '', 0, 0, 0, 0, '', 0, TM, tm, null, null, null, null, null 
    from impactResults a, TB_includes b
  where a.fonte=b.nome 
  
  insert into impactCatalog
  select distinct c.sigla, 1109, 'Tabelas', b.REDEFINES, 'ddl', 0, 0, 0, '', 0, 0, 0, 0, '', 0, getdate(), getdate(), null, null, null, null, null  
  from impactResults a, tb_variaveis b, impactCatalog c where a.tp=99 and b.fonte=a.fonte and b.area='2' and a.nome=replace(b.nome,'_','-') and b.REDEFINES<>''
    and a.programa=c.nome
    and 1 not in ( select 1 from impactCatalog where nome=REDEFINES and tp=1109 )

  insert into impactCatalog
  select distinct substring(ddname,2,2), 1109, 'Tabelas', b.DDNAME, 'ddl', 0, 0, 0, '', 0, 0, 0, 0, '', 0, getdate(), getdate(), null, null, null, null, null  
  from impactResults a, TB_ARQUIVOS b
  where a.nome=b.ddname and b.tipo in (4, 128 )
    and 1 not in ( select 1 from impactCatalog where nome=DDNAME and tp=1109 )
  
  insert into impactCatalog
  select distinct substring(a2.ddname,2,2), 1109, 'Tabelas', b.DDNAME, 'ddl', 0, 0, 0, '', 0, 0, 0, 0, '', 0, getdate(), getdate(), null, null, null, null, null  
  from impactResults a1, tb_ioarea a2, TB_ARQUIVOS b
  where a1.programa=a2.PROGRAMA and a1.nome=a2.REGISTRO and a2.programa=b.programa and a2.DDNAME=b.ddname and b.tipo in (4, 128 )
    and 1 not in ( select 1 from impactCatalog where nome=a2.DDNAME and tp=1109 )
  
  insert into impactCatalog
  select distinct '', 12, 'Dsname', b.nome, '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, GETDATE(), getdate(), null, null, null, null, null 
  from impactResults a, TB_DATASETS b
  where a.nome=b.nome
  
  insert into impactCatalog
  select distinct '', b.tipo, 'Cardlib', objeto, '', 0, 0, 0, '', 0, 0, 0, 0, '', 0, GETDATE(), getdate(), null, null, null, null, null 
   from impactResults a, tabimpact b
  where a.nome=b.objeto and b.tipo=1105
  and b.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )
  
  update a set sigla=substring(jcl,1,2) from impactCatalog a, tb_jclstep b where a.tp=12 and sigla='' and a.nome=b.DATASETNAME and b.LRECL>0
  update a set sigla=substring(jcl,1,2) from impactCatalog a, tb_jclstep b where a.tp=12 and sigla='' and a.nome=b.DATASETNAME 
  
  update a set sigla=d.sigla from impactCatalog a, TABIMPACT b, TABIMPACT c, impactCatalog d where a.tp=1105 and b.OBJETO=a.nome
  and c.seq=b.id and d.nome=c.OBJETO
  and b.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )
  and c.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )
  
  update impactCatalog set sigla='' where tp=10
  update a set sigla=substring(nome,1,2) from impactCatalog a where a.tp=10 and substring(nome,1,2) in ( select sigla from impactCatalog where sigla<>'' )
  update a set sigla=substring(nome,1,1)+substring(nome,5,1) from impactCatalog a where a.tp=10 and substring(nome,1,1)+substring(nome,5,1) in ( select sigla from impactCatalog where sigla<>'' ) and sigla=''
  update a set sigla=substring(nome,1,2) from impactCatalog a where a.sigla='' and tp=10

  update a set sigla=c.sigla from impactCatalog a, RL_PROGRAMAS b, impactCatalog c where a.tp=10 and a.nome=b.OBJETO and c.nome=chave

  --update a set sigla=substring(nome,1,2) from impactCatalog a where a.sigla='' and tp=7
  update a set sigla=substring(nome,1,2) from impactCatalog a where tp=12 and substring(nome,3,1)='.'

  update a set sigla=x.sigla from impactCatalog a, impactResults b, impactResults c, impactResults d, impactCatalog x where a.tp=1105 and a.id=b.id
    and c.id=b.idimp
    and d.id=c.idimp
	and x.nome=d.programa
  update a set sigla=x.sigla from impactCatalog a, impactResults b, impactResults c, impactResults d, impactresults e, impactCatalog x where a.tp=1105 and a.id=b.id
    and c.id=b.idimp
    and d.id=c.idimp
    and e.id=d.idimp
	and x.nome=e.programa

  update a set qtdref=(select count(distinct(linfon)) from impactResults where fonte=a.nome) from impactCatalog a where a.tp=10
  update a set qtdtip=(select count(distinct(linfon)) from impactResults where fonte=a.nome and tpImpact='tipo') from impactCatalog a where a.tp=10
  update a set qtdtam=(select count(distinct(linfon)) from impactResults where fonte=a.nome and tpImpact like 'tam%') from impactCatalog a where a.tp=10
  
  update a set qtdref=(select count(distinct(linfon)) from impactResults where programa=a.nome) from impactCatalog a where a.tp=9
  update a set qtdtip=(select count(distinct(linfon)) from impactResults where programa=a.nome and tpImpact='tipo') from impactCatalog a where a.tp=9
  update a set qtdtam=(select count(distinct(linfon)) from impactResults where programa=a.nome and tpImpact like 'tam%') from impactCatalog a where a.tp=9
  
  update a set qtdref=(select count(distinct(linfon)) from impactResults where programa=a.nome) from impactCatalog a where a.tp=14
  update a set qtdtip=(select count(distinct(linfon)) from impactResults where programa=a.nome and tpImpact='tipo') from impactCatalog a where a.tp=14
  update a set qtdtam=(select count(distinct(linfon)) from impactResults where programa=a.nome and tpImpact like 'tam%') from impactCatalog a where a.tp=14
  
  update a set qtdref=(select count(distinct(linfon)) from impactResults where nome=a.nome) from impactCatalog a where a.tp=1109
  update a set qtdtip=(select count(distinct(linfon)) from impactResults where nome=a.nome and tpImpact='tipo') from impactCatalog a where a.tp=1109
  update a set qtdtam=(select count(distinct(linfon)) from impactResults where nome=a.nome and tpImpact like 'tam%') from impactCatalog a where a.tp=1109
  
  --update a set sigla=s2 from impactCatalog a, ss b where a.tp=1109 and a.sigla=b.s1
  update a set sigla=substring(nome,1,2) from impactCatalog a where a.tp=1109 --and nome like 'TB%'
  update a set sigla=c.sigla from impactCatalog a, TB_ARQUIVOS b, impactCatalog c where a.tp=1109 --and a.nome like 'T%'
     and b.DDNAME=a.nome and b.programa=c.nome

  update a set tpImpacto=ltrim(tpImpacto+' '+b.tpimpact) from impactCatalog a, impactResults b where a.nome=b.programa and b.tpImpact='TIPO' and a.tpImpacto not like '%'+tpImpact+'%'
  update a set tpImpacto=ltrim(tpImpacto+' '+b.tpimpact) from impactCatalog a, impactResults b where a.nome=b.programa and b.tpImpact like 'tam%' and a.tpImpacto not like '%'+tpImpact+'%'
  update a set tpImpacto=ltrim(tpImpacto+' '+b.tpimpact) from impactCatalog a, impactResults b where a.nome=b.fonte and b.tpImpact='TIPO' and a.tpImpacto not like '%'+tpImpact+'%'
  update a set tpImpacto=ltrim(tpImpacto+' '+b.tpimpact) from impactCatalog a, impactResults b where a.nome=b.fonte and b.tpImpact like 'tam%' and a.tpImpacto not like '%'+tpImpact+'%'
  update a set tpImpacto=ltrim(tpImpacto+' '+b.tpimpact) from impactCatalog a, impactResults b where a.nome=b.nome and b.tpImpact='TIPO' and a.tpImpacto not like '%'+tpImpact+'%'
  update a set tpImpacto=ltrim(tpImpacto+' '+b.tpimpact) from impactCatalog a, impactResults b where a.nome=b.nome and b.tpImpact like 'tam%' and a.tpImpacto not like '%'+tpImpact+'%'
  update a set tpImpacto=c.tpImpact from impactCatalog a, TB_IOAREA b, impactResults c where a.tp=1109 and b.DDNAME=a.nome
     and c.programa=b.PROGRAMA and c.nome=b.REGISTRO and c.tpImpact<>''
  update a set tpImpacto=c.tpImpact from impactCatalog a, TB_VARIAVEIS b, impactResults c where a.tpImpacto='' and a.tp=1109
     and b.programa='tabledb2' and b.REDEFINES=a.nome --and b.area<>'2'
	 and c.fonte=b.FONTE and c.nome=replace(b.nome,'_','-') and c.tpImpact<>''

  update a set e_name=replace(e_name,char(39)+'+char(64)+'+char(39),'*') from MAPFIELD a where e_name like '%'+char(39)+'+char(64)+'+char(39)+'%'
  
  update a set linhas=b.linhas from impactCatalog a, TB_PROGRAMAS b where a.nome=b.nome and b.ext<>'PSB'
  
  update x set qtdlin=  
  ( select count(distinct(b.nrolinha)) from impactResults a, TB_VARVAR b where a.programa=x.nome and a.tp=99 and b.programa=a.programa and ( a.nome=vr1 or a.nome=vr2 ) )
  from impactCatalog x where tp=9
  
  update x set qtdarq=
  ( select count(*) from impactResults a where a.programa=x.nome and tp=93 and tpImpact<>'' )
  from impactCatalog x where tp=9
  update x set qtdtel=
  ( select count(*) from impactResults a, tb_ioarea b where tp=1402 and tpImpact<>'' and a.nome=b.DDNAME and b.programa=x.nome )
  from impactCatalog x where tp=9
  
  update a set pontos=qtdtel+qtdarq+(qtdlin / 10)+(case when (qtdlin % 10)>0 then 1 else 0 end) from impactCatalog a where tp=9
  update x set pontos=(
  select count(distinct(b.nrolin)) from impactCatalog a, TB_JCLSTEP b, impactResults c where a.nome=x.nome and a.tp=7 
  and b.jcl=a.nome and b.DATASETNAME=c.nome and c.tpImpact<>''
  ) from impactCatalog x where tp=7
  
  update x set pontos=pontos+(
  select count(distinct(b.nrolin)) from impactCatalog a, TB_JCLSTEP b, impactResults c where a.nome=x.nome and a.tp=7 
  and b.jcl=a.nome and b.membro=c.nome and c.tpImpact<>''
  ) from impactCatalog x where tp=7
    
  update a set grau=(case when pontos between 1 and 5 then 'S' when pontos between 6 and 10 then 'F' when pontos between 11 and 15 then 'M' when pontos between 16 and 20 then 'D'  else 'C' end ) from impactCatalog a where tp=9 
  update a set grau=(case when pontos between 1 and 5 then 'S' when pontos between 6 and 10 then 'F' when pontos between 11 and 15 then 'M' when pontos between 16 and 20 then 'D'  else 'C' end ) from impactCatalog a where tp=7
  
  update a set id=b.seq, niv=b.nivel from impactCatalog a, TABIMPACT b where a.nome=b.objeto and a.tp=b.TIPO
  and b.CLASSE not in ( '', 'CPF', 'CPFBASE', 'DAC', 'DACCPF', 'DAC3' )
  
  update x set qtdwrk=
  ( select count(*) from impactResults a where a.programa=x.nome and programa=fonte and tpImpact<>'' )
  from impactCatalog x where tp=9
  
  update a set sigla=x.sigla from impactCatalog a, impactResults b, impactResults c, impactResults d, impactCatalog x where a.tp=1105 and a.id=b.id
    and c.id=b.idimp
    and d.id=c.idimp
	and x.nome=d.programa
  update a set sigla=x.sigla from impactCatalog a, impactResults b, impactResults c, impactResults d, impactresults e, impactCatalog x where a.tp=1105 and a.id=b.id
    and c.id=b.idimp
    and d.id=c.idimp
    and e.id=d.idimp
	and x.nome=e.programa

  update a set linhas=b.LINHA from impactCatalog a, TB_INVENTARIO b where a.linhas=0 and b.fonte=a.nome and b.EXTENSAO=a.ext

  update impactCatalog set dscimp=null
  update a set dscImp='Niv 5 (l�gica)' from impactCatalog a, impactResults b, TB_VARVAR c where a.tp=9 and dscimp is null 
  and b.programa=a.nome and b.tp=99 and c.PROGRAMA=b.programa and c.vr1=b.nome and c.vr2='NUMERIC'
  update a set dscImp='Niv 5 (l�gica)' from impactCatalog a, impactResults b, TB_VARVAR c where a.tp=9 and dscimp is null 
  and b.programa=a.nome and b.tp=99 and c.PROGRAMA=b.programa and c.vr1=b.nome and c.acao='COMPUTE'
  update a set dscImp='Niv 0 (nulo)' from impactCatalog a where a.tp=9 and dscimp is null and a.tpImpacto='' and qtdlin=0
  update a set dscImp='Niv 1a (tam)' from impactCatalog a where a.tp=9 and dscimp is null and a.tpImpacto like 'tam%' and qtdlin=0
  update a set dscImp='Niv 1b (tipo)' from impactCatalog a where a.tp=9 and dscimp is null and a.tpImpacto='TIPO' and qtdlin=0
  update a set dscImp='Niv 2 (tipo/uso)' from impactCatalog a where a.tp=9 and dscimp is null and a.tpImpacto='TIPO'
  update a set dscImp='Niv 3 (tipo/tam)' from impactCatalog a where a.tp=9 and dscimp is null and qtdlin=0
  update a set dscImp='Niv 4 (tipo/tam/uso)' from impactCatalog a where a.tp=9 and dscimp is null 
end
--go

--exec  #mapp_results

