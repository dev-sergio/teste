drop table impactError
go

create table impactError (
  programa varchar(255),
  fonte    varchar(255),
  varerr   varchar(255),
  txt      varchar(255)
)
go

insert into impactError values ( 'REX02', 'BP40N', 'RE02-P-TPDOC-SERASIGA-N', 'IF RE02-P-TPDOC-SERASIGA-N  NOT EQUAL  SERA0151-NUMERO-P' )
insert into impactError values ( 'PRX12', 'FRCOHOST', 'COHOST-SETO-SETOR-N', 'MOVE  PRLOTMOV-1-CGC-N            TO  COHOST-SETO-SETOR-N.' )
insert into impactError values ( 'UCSCORE', 'UCSCORE', 'UCSCORE-QCHEQUE-B', 'MOVE    UCSCORE-QCHEQUE-B  TO  NU-CGC-LOJISTA-LOG' )
insert into impactError values ( 'UCSCORE', 'UCSCORE', 'UCSCORE-QT-TOTAL-PARC-N', 'MOVE    UCSCORE-QT-TOTAL-PARC-N' )

--update tabimpact set classe='INSCR-JC' where classe='INSC-JUNTA'
