--drop proc #ImpactoMapearMainframeSementes
--\go
create proc #ImpactoMapearMainframeSementes (@crit varchar(255) = '*', @ling varchar(20) = '*', @fmt varchar(255) = '*', @tpinfo varchar(255) = '*' ) as 
begin
  if exists ( select 1 from sysobjects where name='TempMain' )
    drop table TempMain
  create table TempMain
  (
     seq   integer identity,
	 filtro varchar(30),
	 impacto varchar(30),
     Fonte varchar(10),
	 ext   varchar(3),
	 nome  varchar(255),
	 tipo  char(1),
	 formato char(1),
	 tamanho int,
	 maskedit varchar(80),
	 tpInfo  varchar(255),
	 Linguagem varchar(255),
	 classe varchar(255),
	 id integer,
	 niv int,
	 lin int,
	 ate int,
	 cc varchar(255)
  )

  create index ix1 on tempMain ( fonte, nome )
  create index ix2 on tempMain ( classe )
  create index ix3 on tempMain ( tamanho )

  /*
  if @tpinfo = '*' or @tpinfo='DDL'
  insert into TempMain 
  select DISTINCT FONTE, 'DB2', nome, MASKEDIT+'('+LTRIM(STR(TAMANHO))+')', tamanho, 'DDL', 'SQL', ''--, NULL
    from TB_VARIAVEIS a where ( a.nome like '%CPF%' or a.nome like '%CGC%' or a.nome like '%CNPJ%' ) and programa='tabledb2' AND TAMANHO IN (14,15)
	 and precisao=0
  */

  --- ITENS DE GRUPO *CNP* *CGC* *CPF* 14, 15, 16, 18
  insert into TempMain 
  select distinct 'Grupo01', '', a.fonte, e.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), e.LINGUAGEM, 'CNPJ'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.nivel, a.linhafonte, 0, null
    from TB_VARIAVEIS a, TB_PROGRAMAS e where a.tipo='G' and a.TAMANHO in ( 14, 15, 16, 18 )
		 and ( a.nome like '%cnp%' or a.nome like '%cgc%' or a.nome like '%cpf%' )
		 and e.nome=a.PROGRAMA and e.ext<>'psb'
  order by 'Vari�vel '+replace(a.fonte,'$',''), a.LINHAFONTE

  insert into TempMain 
  select distinct 'Numbase_b', '', a.fonte, e.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), e.LINGUAGEM, 'CNPJ'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.nivel, a.linhafonte, 0, null
    from TB_VARIAVEIS a, TB_PROGRAMAS e where ( a.nome like '%CNPJ%' or a.nome like '%CGC%' )
     and area<>'2' and tamanho=9 and formato='B'
     and e.nome=a.PROGRAMA and e.ext<>'psb'

  /*
  insert into TempMain 
  select distinct 'Grupo842', '', a.fonte, e.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), e.LINGUAGEM, 'CNPJ'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.nivel, a.linhafonte, 0, null
    from TB_VARIAVEIS a, tb_variaveis b, tb_variaveis c, tb_variaveis d, TB_PROGRAMAS e where a.tipo='G' and a.TAMANHO=14
		 --and ( a.nome like '%cnp%' or a.nome like '%cgc%' or a.nome like '%cpf%' )
		 and b.PROGRAMA=a.PROGRAMA and b.OFFSET=a.OFFSET+0 and b.TAMANHO=8 and b.nome not like '%DAT%' and b.nome not like '%DT%'
		 and c.PROGRAMA=a.PROGRAMA and c.OFFSET=a.OFFSET+8 and c.TAMANHO=4
		 and d.PROGRAMA=a.PROGRAMA and d.OFFSET=a.OFFSET+12 and d.TAMANHO=2
		 and 'CNPJ'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL) not like '%3%'
         and 1 not in ( select 1 from TempMain x where x.fonte=b.fonte and x.nome=b.nome and x.lin=b.LINHAFONTE )
		 and e.nome=a.PROGRAMA and e.ext<>'psb'
  order by 'Vari�vel '+replace(a.fonte,'$',''), a.LINHAFONTE
  */

  update a set ate=(select min(linhafonte)-1 from TB_VARIAVEIS b where b.fonte=a.fonte and b.LINHAFONTE>a.lin and ( b.NIVEL<=a.niv or b.NIVEL>49 ) ) from tempMain a where a.tipo='G' and a.ate=0
  update a set ate=(select max(linhafonte) from TB_VARIAVEIS b where b.fonte=a.fonte) from tempMain a where a.tipo='G' and a.ate is null

  insert into TempMain 
  select 'Subcamposg1', '', b.fonte, e.ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, 'Vari�vel '+replace(b.fonte,'$',''), e.LINGUAGEM, min(a.classe+'_P'+ltrim(str(b.OFFSET-a1.OFFSET))), max(a.seq), b.nivel, b.LINHAFONTE, 0, null
	    from TempMain a, TB_VARIAVEIS a1, TB_VARIAVEIS b, TB_PROGRAMAS e where a.ate>0 and a.fonte=a1.fonte and a.nome=a1.nome
         and b.programa=a1.PROGRAMA and b.OFFSET>=a1.OFFSET and b.OFFSET<a1.OFFSET+a1.TAMANHO and b.LINHAFONTE between a.lin and a.ate
		 and b.nome<>a.nome and b.FONTE=a1.FONTE
		 and e.nome=a1.programa and e.ext<>'psb'
         and 1 not in ( select 1 from TempMain x where x.fonte=b.fonte and x.nome=b.nome and x.lin=b.LINHAFONTE )
  group by b.fonte, e.ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, e.LINGUAGEM, b.nivel, b.LINHAFONTE
  order by replace(b.fonte,'$',''), b.LINHAFONTE

  --select * from tempMain

  --- TIPO PESSOA
  insert into TempMain 
      select distinct 'Pessoa1', '', b.fonte, ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, 'Vari�vel '+replace(b.fonte,'$',''), c.LINGUAGEM, 'TPPESSOA', 0, b.NIVEL, b.LINHAFONTE, 0, null
      from tb_varvar a, tb_variaveis b, tb_programas c where a.vr2 in ( char(39)+'F'+char(39), char(39)+'J'+char(39) )
      and ( vr1 like '%PES%' or vr1 like '%FJ%' or vr1 like '%TP%CLI%'  or vr1 like '%JUR%'  or vr1 like '%FIS%'  )
      and b.programa=a.programa and b.LINHAEXP=linvr1 and b.TAMANHO=1
      and c.nome=b.programa and c.ext<>'PSB'
      and precisao=0
      and 1 not in ( select 1 from TempMain x where x.fonte=b.fonte and x.nome=b.nome )
      order by 'Vari�vel '+replace(b.fonte,'$',''), b.LINHAFONTE
      
  insert into TempMain 
      select distinct 'Pessoa2', '', b.fonte, ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, 'Vari�vel '+replace(b.fonte,'$',''), c.LINGUAGEM, 'TPPESSOA', 0, b.NIVEL, b.LINHAFONTE, 0, null
      from tb_varvar a, tb_variaveis b, tb_programas c 
      where a.vr1 in ( char(39)+'F'+char(39), char(39)+'J'+char(39) ) and vr2<>''
      and ( vr2 like '%PES%' or vr2 like '%FJ%' or vr2 like '%TP%CLI%'  or vr2 like '%JUR%'  or vr2 like '%FIS%'  )
      and b.programa=a.programa and b.LINHAEXP=linvr2 and b.TAMANHO=1
      and c.nome=b.programa and c.ext<>'PSB'
      and precisao=0
      and 1 not in ( select 1 from TempMain x where x.fonte=b.fonte and x.nome=b.nome )
      order by 'Vari�vel '+replace(b.fonte,'$',''), b.LINHAFONTE
      
  insert into TempMain 
      select distinct 'Pessoa3', '', a.fonte, c.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), c.LINGUAGEM, 'TPPESSOA', 0, a.NIVEL, a.LINHAFONTE, 0, null
        from TB_VARIAVEIS a, TB_PROGRAMAS c where a.nome like 'FJ%' and a.tipo='X' and a.TAMANHO=1 and a.area not in ( '2', 'a' )
	     and c.nome=a.PROGRAMA and c.EXT<>'PSB'
         and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )
      order by 'Vari�vel '+replace(a.fonte,'$',''), a.LINHAFONTE
      
  insert into TempMain 
      select distinct 'Pessoa4', '', a.fonte, c.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), c.LINGUAGEM, 'TPPESSOA', 0, a.NIVEL, a.LINHAFONTE, 0, null
        from TB_VARIAVEIS a, TB_VARIAVEIS b, TB_PROGRAMAS c where a.nome like '%PES%' and a.tipo='X' and a.TAMANHO=1 and a.area not in ( '2', 'a' )
         and b.PROGRAMA=a.PROGRAMA and b.OFFSET=a.OFFSET+a.TAMANHO and ( b.nome like '%CPF%' or b.nome like '%CGC%' or b.nome like '%CNPJ%' )
         and b.TAMANHO>=14 and b.PRECISAO=0 and a.nivel<>77 and b.FONTE=a.fonte
	     and c.nome=b.PROGRAMA and c.EXT<>'PSB'
         and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )
      order by 'Vari�vel '+replace(a.fonte,'$',''), a.LINHAFONTE

  -- select * from tempMain
  -- select * from tb_variaveis where programa='$AL0IB4C' order by linhaexp
  
  -- CNPJ CONJUGADOS COM TIPO PESSOA
  insert into TempMain 
      select distinct 'PessoaCnpj', '', b.fonte, c.ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, 'Vari�vel '+replace(b.fonte,'$',''), c.LINGUAGEM, 
	        (case when b.tamanho=8 then 'NUMBASE' when b.tamanho=12 then 'BASEFIL' else 'CNPJ' end)+dbo.subOffsets(b.programa, b.nome, b.LINHAEXP, b.NIVEL), a1.seq, b.NIVEL, b.LINHAFONTE, 0, null
      from tempMain a1, TB_VARIAVEIS a2, TB_VARIAVEIS b, TB_PROGRAMAS c where a1.classe='TPPESSOA'
	    and a2.fonte=a1.fonte and a2.NOME=a1.nome and b.FONTE=a2.FONTE
       and b.PROGRAMA=a2.PROGRAMA and b.OFFSET=a2.OFFSET+a2.TAMANHO and ( b.nome like '%CPF%' or b.nome like '%CGC%' or b.nome like '%CNP%' )
       and b.TAMANHO in (8,12,14) and b.PRECISAO=0 and a2.nivel<>77
	     and c.nome=b.PROGRAMA and c.EXT<>'PSB'
       and 1 not in ( select 1 from TempMain x where x.fonte=b.fonte and x.nome=b.nome )
       and 1 not in ( select 1 from TempCpf x where x.fonte=b.fonte and x.nome=b.nome )
      order by 'Vari�vel '+replace(b.fonte,'$',''), b.LINHAFONTE

  update a set ate=(select min(linhafonte)-1 from TB_VARIAVEIS b where b.fonte=a.fonte and b.LINHAFONTE>a.lin and ( b.NIVEL<=a.niv or b.NIVEL>49 ) ) from tempMain a where a.tipo='G' and a.ate=0 and a.filtro='PessoaCnpj'
  update a set ate=(select max(linhafonte) from TB_VARIAVEIS b where b.fonte=a.fonte) from tempMain a where a.tipo='G' and a.ate is null and a.filtro='PessoaCnpj'

  insert into TempMain 
  select 'Subcamposg2', '', b.fonte, e.ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, 'Vari�vel '+replace(b.fonte,'$',''), e.LINGUAGEM, min(a.classe+'_P'+ltrim(str(b.OFFSET-a1.OFFSET))), max(a.seq), b.nivel, b.LINHAFONTE, 0, null
	    from TempMain a, TB_VARIAVEIS a1, TB_VARIAVEIS b, TB_PROGRAMAS e where a.ate>0 and a.filtro='PessoaCnpj' and a.fonte=a1.fonte and a.nome=a1.nome
         and b.programa=a1.PROGRAMA and b.OFFSET>=a1.OFFSET and b.OFFSET<a1.OFFSET+a1.TAMANHO and b.LINHAFONTE between a.lin and a.ate
		 and b.nome<>a.nome and b.FONTE=a1.FONTE
		 and e.nome=a1.programa and e.ext<>'psb'
         and 1 not in ( select 1 from TempMain x where x.fonte=b.fonte and x.nome=b.nome and x.lin=b.LINHAFONTE )
  group by b.fonte, e.ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, e.LINGUAGEM, b.nivel, b.LINHAFONTE
  order by replace(b.fonte,'$',''), b.LINHAFONTE

  -- CNPJ ALFA OU NUM 14 A 18
  insert into TempMain 
    select distinct 'CNPJNomeTipo', '', fonte, ext, a.NOME, a.tipo, a.formato, a.tamanho, MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), LINGUAGEM, 'CNPJ'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.NIVEL, a.LINHAFONTE, 0, null
    from TB_VARIAVEIS a, tb_programas  b where ( a.nome like '%CGC%' or a.nome like '%CNPJ%' ) and a.tipo IN ('9','X') AND TAMANHO between 14 and 18 and precisao=0
    and area not in ( '2', 'a' ) --and programa<>fonte
    and b.nome=a.PROGRAMA and b.EXT<>'PSB'
    and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )
  order by 'Vari�vel '+replace(a.fonte,'$',''), a.LINHAFONTE

  insert into TempMain 
    select distinct 'CNPJNomeTipo', '', fonte, ext, a.NOME, a.tipo, a.formato, a.tamanho, MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), LINGUAGEM, 'CNPJ'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.NIVEL, a.LINHAFONTE, 0, null
    from TB_VARIAVEIS a, tb_programas  b where ( a.nome like '%CGC%' or a.nome like '%CNPJ%' ) and a.tipo IN ('9','X') AND TAMANHO=9 and precisao=0 and formato='b'
    and area not in ( '2', 'a' ) --and programa<>fonte
    and b.nome=a.PROGRAMA and b.EXT<>'PSB'
    and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )
  order by 'Vari�vel '+replace(a.fonte,'$',''), a.LINHAFONTE

  --select distinct filtro from tempMain
  -- REDEFINICOES DOS CNPJ IDENTIFICADOS
  /*
  insert into TempMain 
  select top 1 c.fonte, a.ext, c.NOME, c.tipo, c.formato, c.tamanho, c.MASKEDIT, 'Vari�vel', LINGUAGEM, 'CNPJ'+dbo.subOffsets(c.programa, c.nome, c.LINHAEXP, c.NIVEL), 0, c.NIVEL, c.LINHAFONTE, 0
    from TempMain a, TB_VARIAVEIS b, TB_VARIAVEIS c 
   where a.tamanho>1 and b.fonte=a.Fonte and b.nome=a.nome and b.REDEFINES<>''
     and c.programa=b.programa and c.nome=b.REDEFINES and c.nome<>'FILLER'  and c.TAMANHO>20
     and 1 not in ( select 1 from TempMain x where x.fonte=c.fonte and x.nome=c.nome )
 
  insert into TempMain 
  select distinct c.fonte, a.ext, c.NOME, c.tipo, c.formato, c.tamanho, c.MASKEDIT, 'Vari�vel', LINGUAGEM, 'CNPJ'+dbo.subOffsets(c.programa, c.nome, c.LINHAEXP, c.NIVEL), 0, c.NIVEL, c.LINHAFONTE, 0
    from TempMain a, TB_VARIAVEIS b, TB_VARIAVEIS c 
   where a.tamanho>1 and b.fonte=a.Fonte and b.nome=a.nome 
     and c.programa=b.programa and c.REDEFINES=b.nome and c.nome<>'FILLER'
     and 1 not in ( select 1 from TempMain x where x.fonte=c.fonte and x.nome=c.nome )
  */

  update a set ate=(select min(linhafonte)-1 from TB_VARIAVEIS b where b.fonte=a.fonte and b.LINHAFONTE>a.lin and ( b.NIVEL<=a.niv or b.NIVEL>49 ) ) from tempMain a where a.tipo='G' and a.ate=0
  update a set ate=(select max(linhafonte) from TB_VARIAVEIS b where b.fonte=a.fonte) from tempMain a where a.tipo='G' and a.ate is null

  --update a set classe=classe+dbo.subOffsets(b.programa, b.nome, b.LINHAEXP, b.NIVEL) from TempMain a, TB_VARIAVEIS b where a.ate>0 and a.tamanho>1
  --   and b.fonte=a.fonte and b.nome=a.nome

  update a set filtro=filtro+'@', ate=(select min(linhafonte)-1 from TB_VARIAVEIS x where x.fonte=c.fonte and x.LINHAFONTE>c.linhafonte and x.NIVEL<=c.nivel)
    from TempMain a, TB_VARIAVEIS b, TB_VARIAVEIS c where a.tipo<>'G' and a.ate=0
     and b.fonte=a.fonte and b.nome=a.nome and c.programa=b.programa and c.REDEFINES=b.nome and c.tipo='G' and c.nome='FILLER'
  update a set filtro=filtro+'@', ate=(select min(linhafonte)-1 from TB_VARIAVEIS x where x.fonte=c.fonte and x.LINHAFONTE>c.linhafonte and x.NIVEL<=c.nivel)
    from TempMain a, TB_VARIAVEIS b, TB_VARIAVEIS c where a.tipo<>'G' and a.ate=0
     and b.fonte=a.fonte and b.nome=a.nome and c.programa=b.programa and c.REDEFINES=b.nome and c.tipo='G' and c.nome not like 'FILLER%'
     and 1 not in ( select 1 from TempMain x where x.fonte=c.fonte and x.nome=c.nome )

  update a set classe=classe+dbo.subOffsets(c.programa, c.nome, c.LINHAEXP, c.NIVEL) from TempMain a, TB_VARIAVEIS b, TB_VARIAVEIS c where a.tipo<>'G' and a.ate>0 and a.tamanho>1
     and b.fonte=a.fonte and b.nome=a.nome
	 and c.programa=b.PROGRAMA and c.LINHAFONTE>=a.lin and c.LINHAFONTE<=a.ate and c.TAMANHO=a.tamanho and c.tipo='G' and c.fonte=a.fonte

  insert into TempMain 
  select 'Subcampos', '', b.fonte, e.ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, 'Vari�vel '+replace(b.fonte,'$',''), e.LINGUAGEM, min(a.classe+'_P'+ltrim(str(b.OFFSET-a1.OFFSET))), max(a.seq), b.nivel, b.LINHAFONTE, 0, null
	    from TempMain a, TB_VARIAVEIS a1, TB_VARIAVEIS b, TB_PROGRAMAS e where a.filtro like '%@' and a.ate>0 and a.fonte=a1.fonte and a.nome=a1.nome
         and b.programa=a1.PROGRAMA and b.OFFSET>=a1.OFFSET and b.OFFSET<a1.OFFSET+a1.TAMANHO and b.LINHAFONTE between a.lin and a.ate
		 and b.nome<>a.nome and b.FONTE=a1.FONTE
		 and e.nome=a1.programa and e.ext<>'psb'
         and 1 not in ( select 1 from TempMain x where x.fonte=b.fonte and x.nome=b.nome and x.lin=b.LINHAFONTE )
  group by b.fonte, e.ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, e.LINGUAGEM, b.nivel, b.LINHAFONTE
  order by replace(b.fonte,'$',''), b.LINHAFONTE

------ MASCARAS DE EDICAO
-- select * from tempMain

  insert into TempMain 
  select distinct 'Grupo02', '', b.fonte, e.ext, b.nome, b.tipo, b.FORMATO, b.TAMANHO, b.MASKEDIT, 'Vari�vel', e.LINGUAGEM, 'NUMBASE'+dbo.subOffsets(b.programa, b.nome, b.LINHAEXP, b.NIVEL), 0, a.NIVEL, a.LINHAFONTE, 0, null
    from TB_VARIAVEIS a, TB_VARIAVEIS b, TB_PROGRAMAS e where a.tipo='G' and a.TAMANHO=16
  and b.PROGRAMA=a.PROGRAMA and b.OFFSET=a.OFFSET and b.TAMANHO=8 and ( a.nome like '%CGC%' or a.nome like '%CNPJ%' )
  and b.nome<>'FILLER'
  and b.fonte=a.fonte
  and 1 not in ( select 1 from TempMain x where x.fonte=b.fonte and x.nome=b.nome and x.lin=b.linhafonte )
  and e.nome=a.PROGRAMA and e.ext<>'PSB'

  insert into TempMain 
  select distinct 'Numbase1', '', fonte, ext, a.NOME, a.tipo, a.formato, a.tamanho, MASKEDIT, 'Vari�vel', LINGUAGEM, 'NUMBASE'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.NIVEL, a.LINHAFONTE, 0, null
  from TB_VARIAVEIS a, tb_programas  b where ( a.nome like '%CGC%' or a.nome like '%CNPJ%' ) and a.tipo IN ('9','X') 
  and TAMANHO=8 and a.TAMANHOFIS=10 and precisao=0
  and area not in ( '2', 'a' ) --and programa<>fonte
  and b.nome=a.PROGRAMA and b.EXT<>'PSB'
  and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )

  insert into TempMain 
  select distinct 'Numbase2', '', fonte, ext, a.NOME, a.tipo, a.formato, a.tamanho, MASKEDIT, 'Vari�vel', LINGUAGEM, 'NUMBASE'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.NIVEL, a.LINHAFONTE, 0, null
  from TB_VARIAVEIS a, tb_programas  b where ( a.nome like '%CGC%' or a.nome like '%CNPJ%' ) and a.tipo IN ('9','X') 
  and TAMANHO=9 and a.TAMANHOFIS=11 and precisao=0
  and area not in ( '2', 'a' ) --and programa<>fonte
  and a.nome not like '%CPF%'
  and b.nome=a.PROGRAMA and b.EXT<>'PSB'
  and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )

  insert into TempMain 
  select distinct 'Basefil1', '', fonte, ext, a.NOME, a.tipo, a.formato, a.tamanho, MASKEDIT, 'Vari�vel', LINGUAGEM, 'BASEFIL'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.NIVEL, a.LINHAFONTE, 0, null
  from TB_VARIAVEIS a, tb_programas  b where ( a.nome like '%CGC%' or a.nome like '%CNPJ%' ) and a.tipo IN ('9','X') 
  AND TAMANHO=12 and a.TAMANHOFIS=15 and precisao=0
  and area not in ( '2', 'a' ) --and programa<>fonte
  and MASKEDIT like '%.%/%'
  and b.nome=a.PROGRAMA and b.EXT<>'PSB'
  and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )

  insert into TempMain 
  select distinct 'Basefil2', '', fonte, ext, a.NOME, a.tipo, a.formato, a.tamanho, MASKEDIT, 'Vari�vel', LINGUAGEM, 'BASEFIL'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.NIVEL, a.LINHAFONTE, 0, null
  from TB_VARIAVEIS a, tb_programas  b where ( a.nome like '%CGC%' or a.nome like '%CNPJ%' ) and a.tipo IN ('9','X') 
  and TAMANHO=13 and a.TAMANHOFIS>14 and precisao=0
  and area not in ( '2', 'a' ) --and programa<>fonte
  and MASKEDIT like '%.%/%'
  and b.nome=a.PROGRAMA and b.EXT<>'PSB'
  and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )

  /*insert into TempMain 
  select distinct 'Basefil2', '', fonte, ext, a.NOME, a.tipo, a.formato, a.tamanho, MASKEDIT, 'Vari�vel', LINGUAGEM, 'CNPJ'+dbo.subOffsets(a.programa, a.nome, a.LINHAEXP, a.NIVEL), 0, a.NIVEL, a.LINHAFONTE, 0, null
  from TB_VARIAVEIS a, tb_programas  b where ( a.nome like '%CGC%' or a.nome like '%CNPJ%' ) and a.tipo IN ('9','X') 
  and area not in ( '2', 'a' ) --and programa<>fonte
  and maskedit like '%8).%4).%2)'
  --908).904).902)
  and b.nome=a.PROGRAMA and b.EXT<>'PSB'
  and 1 not in ( select 1 from TempMain x where x.fonte=a.fonte and x.nome=a.nome )
  */

  insert into TempMain 
  select distinct 'sub', '', b.fonte, ext, b.NOME, b.tipo, b.formato, b.tamanho, MASKEDIT, 'Vari�vel', LINGUAGEM, (case when tamanho<12 then 'NUMBASE' else 'BASEFIL' end)+dbo.subOffsets(a.programa, b.nome, b.LINHAEXP, b.NIVEL), 0, b.NIVEL, b.LINHAFONTE, 0, null
    from TB_IOAREA a, TB_VARIAVEIS b, TB_PROGRAMAS e where a.ddname='$DACCGC' and a.nrolinha%10000=1 and b.programa=a.programa and b.nome=REGISTRO
     and 1 not in ( select 1 from tempMain x where x.fonte=b.fonte and x.nome=b.nome )
	 and e.nome=b.programa and e.ext<>'PSB'

  update tempMain set cc=null

  update b set cc='FALSO' from TempMain a, tempMain b where a.formato='b' and a.id>0 and b.seq=a.id
  update b set cc='FALSO' from TempMain a, tempMain b where a.formato='b' and a.id>0 and b.id=a.id  and ( b.formato='b' or b.tamanho<=3 )
  update b set cc='FALSO' from TempMain a, tempMain b where a.formato='p' and a.id>0 and b.seq=a.id and b.tipo='G'

--  SELECT * from tempOfs where fonte='X0BE31' order by lin
--  SELECT * from tempMain where fonte='$W0Z0' order by lin
--  SELECT * FROM tempmain where cc is null and nome<>'FILLER' order by fonte, lin

  update tempMain set cc =null where cc is not null and cc<>'FALSO'

  update a set cc='CNPJ' from tempMain a where classe='CNPJ_T14' and nome like '%CGC%'
  update a set cc='CNPJ' from tempMain a where classe='CNPJ_T14' and nome like '%CNPJ%'
  update a set cc='CNPJ' from tempMain a where classe='CNPJ_T15' and nome like '%CGC%'
  update a set cc='CNPJ' from tempMain a where classe='CNPJ_T15' and nome like '%CNPJ%'
  update a set cc='CNPJ' from tempMain a where classe='CNPJ_T18' and nome like '%CGC%'
  update a set cc='CNPJ' from tempMain a where classe='CNPJ_T18' and nome like '%CNPJ%'
  update a set cc='CNPJ' from tempMain a where classe='CNPJ_T16' and nome like '%CGC%'
  update a set cc='CNPJ' from tempMain a where classe='CNPJ_T16' and nome like '%CNPJ%'
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%:14' and nome like '%CGC%' and tamanho=14
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%:14' and nome like '%CNPJ%' and tamanho=14
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%:14_P0' and nome like '%CGC%' and tamanho=14
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%:14_P0' and nome like '%CNPJ%' and tamanho=14
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%T14%' and nome like '%CGC%' and tamanho=14
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%T14%' and nome like '%CNPJ%' and tamanho=14
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%T15%' and nome like '%CGC%' and tamanho=15
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%T15%' and nome like '%CNPJ%' and tamanho=15
  update a set cc='PESSOA' from tempMain a where classe like 'TPPESSOA%' 
  update a set cc='CNPJBASE' from tempMain a where classe='NUMBASE_T8' and nome like '%CGC%' 
  update a set cc='CNPJBASE' from tempMain a where classe='NUMBASE_T8' and nome like '%CNPJ%'
  update a set cc='CNPJBASE' from tempMain a where classe='NUMBASE_T9' and nome like '%CGC%' 
  update a set cc='CNPJBASE' from tempMain a where classe='NUMBASE_T9' and nome like '%CNPJ%' 

  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%:14%' and nome like '%CGC%' and tamanho=14 and tipo in ( '9', 'X' )
  update a set cc='CNPJ' from tempMain a where classe like 'CNPJ%:14%' and nome like '%CNPJ%' and tamanho=14 and tipo in ( '9', 'X' )
  update a set cc='CPF' from tempMain a where classe like 'CNPJ%' and nome like '%CPF%' and tamanho=14 and ( nome not like '%CGC%' and nome not like '%CNP%' )

  --SELECT * FROM tempmain where cc is null and nome<>'FILLER' order by fonte, lin

  update a set cc='CPFZEROS' from TempOfs a, tempOfs b where a.tamanho=3 and b.id=a.id and b.tamanho=9 and b.ofs=a.ofs+a.tamanho
  update a set cc='CPFZEROS' from TempOfs a, tempOfs b where a.tamanho=3 and b.id=a.id and b.tamanho=11 and b.ofs=a.ofs+a.tamanho
  update b set cc='CPFBASE' from TempOfs a, tempOfs b where a.tamanho=3 and b.id=a.id and b.tamanho=9 and b.ofs=a.ofs+a.tamanho
  update b set cc='CPFNUM' from TempOfs a, tempOfs b where a.tamanho=3 and b.id=a.id and b.tamanho=11 and b.ofs=a.ofs+a.tamanho
  update b set cc='CPFDAC' from TempOfs a, tempOfs b where a.cc in ( 'CPFBASE', 'CPFNUM' ) and b.id=a.id and b.tamanho=2 and b.ofs=a.ofs+a.tamanho

  update a set cc='CPFNUM' from TempOfs a, tempOfs b where a.tamanho=11 and b.id=a.id and b.tamanho=3 and b.ofs=a.ofs+a.tamanho 
  update b set cc='CPFZEROS' from TempOfs a, tempOfs b where a.tamanho=11 and b.id=a.id and b.tamanho=3 and b.ofs=a.ofs+a.tamanho 

  update a set cc='CNPJBASEFIL' from TempOfs a, tempOfs b where a.tamanho in (12,15) and b.id=a.id and b.tamanho=2 and b.ofs=a.ofs+a.tamanho and ( a.nome like '%CGC%' or a.nome like '%CNP%' ) and ( b.nome like '%DAC%' or b.nome like '%DC%' or b.nome like '%DIG%' )
  update b set cc='CNPJDAC'     from TempOfs a, tempOfs b where a.tamanho in (12,15) and b.id=a.id and b.tamanho=2 and b.ofs=a.ofs+a.tamanho and ( a.nome like '%CGC%' or a.nome like '%CNP%' )  and ( b.nome like '%DAC%' or b.nome like '%DC%' or b.nome like '%DIG%' )

  update a set cc='CNPJBASE'   from TempOfs a, tempOfs b where a.tamanho in (8,9) and b.id=a.id and b.tamanho=6 and b.ofs=a.ofs+a.tamanho and ( a.nome like '%CGC%' or a.nome like '%CNP%' ) 
  update a set cc='CNPJBASE'   from TempOfs a, tempOfs b where a.tamanho in (8,9) and b.id=a.id and b.ofs=a.ofs+a.tamanho and ( a.nome like '%CGC%' or a.nome like '%CNP%' ) and b.nome like '%FILI%'
  update b set cc='CNPJFILDAC' from TempOfs a, tempOfs b where a.tamanho in (8,9) and b.id=a.id and b.tamanho=6 and b.ofs=a.ofs+a.tamanho and ( a.nome like '%CGC%' or a.nome like '%CNP%' ) 

  update a set cc='CPFBASE' from TempOfs a, tempOfs b where a.tamanho in (9, 12, 13) and b.id=a.id and b.tamanho=2 and b.ofs=a.ofs+a.tamanho and a.nome like '%CPF%' and ( b.nome like '%DAC%' or b.nome like '%DC%' or b.nome like '%DIG%' )
  update b set cc='CPFDAC'  from TempOfs a, tempOfs b where a.tamanho in (9, 12, 13) and b.id=a.id and b.tamanho=2 and b.ofs=a.ofs+a.tamanho and a.nome like '%CPF%' and ( b.nome like '%DAC%' or b.nome like '%DC%' or b.nome like '%DIG%' )
  
  update a set cc='CPFFILLER' from TempOfs a, tempOfs b where a.tamanho in (3,5) and b.id=a.id and b.tamanho=9 and b.ofs=a.ofs+a.tamanho and b.nome like '%CPF%' 
  update b set cc='CPFBASE'   from TempOfs a, tempOfs b where a.tamanho in (3,5) and b.id=a.id and b.tamanho=9 and b.ofs=a.ofs+a.tamanho and b.nome like '%CPF%' 
  
  update a set cc='CPFFILLER' from TempOfs a, tempOfs b where a.tamanho in (4) and b.id=a.id and b.tamanho=11 and b.ofs=a.ofs+a.tamanho and b.nome like '%CPF%' 
  update b set cc='CPFBASE'   from TempOfs a, tempOfs b where a.tamanho in (4) and b.id=a.id and b.tamanho=11 and b.ofs=a.ofs+a.tamanho and b.nome like '%CPF%' 
  
  update a set cc='CNPJFILLER' from TempOfs a, tempOfs b where a.tamanho in (5) and b.id=a.id and b.tamanho=9 and b.ofs=a.ofs+a.tamanho and ( b.nome like '%CGC%' or b.nome like '%CNP%' ) 
  update b set cc='CNPJBASE'   from TempOfs a, tempOfs b where a.tamanho in (5) and b.id=a.id and b.tamanho=9 and b.ofs=a.ofs+a.tamanho and ( b.nome like '%CGC%' or b.nome like '%CNP%' ) 

  update a set cc='CPFBASE' from TempOfs a, tempOfs b where a.tamanho in (9, 10, 12, 13) and b.id=a.id and b.tamanho=2 and b.ofs=a.ofs+a.tamanho+1 and a.nome like '%CPF%' and ( b.nome like '%DAC%' or b.nome like '%DC%' or b.nome like '%DIG%' )
  update b set cc='CPFDAC'  from TempOfs a, tempOfs b where a.tamanho in (9, 10, 12, 13) and b.id=a.id and b.tamanho=2 and b.ofs=a.ofs+a.tamanho+1 and a.nome like '%CPF%' and ( b.nome like '%DAC%' or b.nome like '%DC%' or b.nome like '%DIG%' )

  update a set cc='CNPJBASE_BFD' from TempOfs a, TempOfs b, TempOfs c where a.tamanho in (8,9,10,12)
  and b.id=a.id and b.ofs=a.ofs + a.tamanho and b.tamanho=4
  and c.id=a.id and c.ofs=b.ofs + b.tamanho and c.tamanho=2
  update b set cc='CNPJFILIAL' from TempOfs a, TempOfs b, TempOfs c where a.tamanho in (8,9,10,12)
  and b.id=a.id and b.ofs=a.ofs + a.tamanho and b.tamanho=4
  and c.id=a.id and c.ofs=b.ofs + b.tamanho and c.tamanho=2
  update c set cc='CNPJDAC' from TempOfs a, TempOfs b, TempOfs c where a.tamanho in (8,9,10,12)
  and b.id=a.id and b.ofs=a.ofs + a.tamanho and b.tamanho=4
  and c.id=a.id and c.ofs=b.ofs + b.tamanho and c.tamanho=2

  update a set cc='CNPJBASE_BFD' from TempOfs a, TempOfs b, TempOfs c where a.tamanho in (8,9)
  and b.id=a.id and b.ofs=a.ofs + a.tam2+1 and b.tamanho=4
  and c.id=a.id and c.ofs=b.ofs + b.tam2+1 and c.tamanho=2
  update b set cc='CNPJFILIAL' from TempOfs a, TempOfs b, TempOfs c where a.tamanho in (8,9)
  and b.id=a.id and b.ofs=a.ofs + a.tam2+1 and b.tamanho=4
  and c.id=a.id and c.ofs=b.ofs + b.tam2+1 and c.tamanho=2
  update c set cc='CNPJDAC' from TempOfs a, TempOfs b, TempOfs c where a.tamanho in (8,9)
  and b.id=a.id and b.ofs=a.ofs + a.tam2+1 and b.tamanho=4
  and c.id=a.id and c.ofs=b.ofs + b.tam2+1 and c.tamanho=2

  update a set cc='CNPJBASE1_B123F' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho in (2,3) and b.id=a.id and b.ofs=a.ofs + a.tamanho
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho
  and d.tamanho=4
  update b set cc='CNPJBASE2' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho in (2,3) and b.id=a.id and b.ofs=a.ofs + a.tamanho
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho
  and d.tamanho=4
  update c set cc='CNPJBASE3' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho in (2,3) and b.id=a.id and b.ofs=a.ofs + a.tamanho
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho
  and d.tamanho=4
  update d set cc='CNPJFILIAL' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho in (2,3) and b.id=a.id and b.ofs=a.ofs + a.tamanho
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho
  and d.tamanho=4

  update a set cc='CPFBASE1' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho=3 and b.id=a.id and b.ofs=a.ofs + a.tamanho
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho
  and d.tamanho=2
  update b set cc='CPFBASE2' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho=3 and b.id=a.id and b.ofs=a.ofs + a.tamanho
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho
  and d.tamanho=2
  update c set cc='CPFBASE3' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho=3 and b.id=a.id and b.ofs=a.ofs + a.tamanho
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho
  and d.tamanho=2
  update d set cc='CPFDAC' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho=3 and b.id=a.id and b.ofs=a.ofs + a.tamanho
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho
  and d.tamanho=2

  update a set cc='CNPJBASE1_B1_2_3_F' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho in (2,3) and b.id=a.id and b.ofs=a.ofs + a.tamanho+1
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho+1
  and d.tamanho=4
  update b set cc='CNPJBASE2' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho in (2,3) and b.id=a.id and b.ofs=a.ofs + a.tamanho+1
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho+1
  and d.tamanho=4
  update c set cc='CNPJBASE3' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho in (2,3) and b.id=a.id and b.ofs=a.ofs + a.tamanho+1
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho+1
  and d.tamanho=4
  update d set cc='CNPJFILIAL' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho in (2,3) and b.id=a.id and b.ofs=a.ofs + a.tamanho+1
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho+1
  and d.tamanho=4

  update a set cc='CPFBASE1' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho=3 and b.id=a.id and b.ofs=a.ofs + a.tamanho+1
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho+1
  and d.tamanho=2
  update b set cc='CPFBASE2' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho=3 and b.id=a.id and b.ofs=a.ofs + a.tamanho+1
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho+1
  and d.tamanho=2
  update c set cc='CPFBASE3' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho=3 and b.id=a.id and b.ofs=a.ofs + a.tamanho+1
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho+1
  and d.tamanho=2
  update d set cc='CPFDAC' from TempOfs a, TempOfs b, TempOfs c, TempOfs d where 
      a.tamanho=3 and b.id=a.id and b.ofs=a.ofs + a.tamanho+1
  and b.tamanho=3 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=3 and d.id=a.id and d.ofs=c.ofs + c.tamanho+1
  and d.tamanho=2

  update a set cc='CPFBASE' from TempOfs a, TempOfs b, TempOfs c where 
      a.tam2 in (9,11) and b.id=a.id and b.ofs=a.ofs + a.tam2
  and b.tamanho=1 and c.id=a.id and c.ofs=b.ofs + b.tam2
  and c.tamanho=2
  update c set cc='CPFDAC' from TempOfs a, TempOfs b, TempOfs c where 
      a.tam2 in (9,11) and b.id=a.id and b.ofs=a.ofs + a.tam2
  and b.tamanho=1 and c.id=a.id and c.ofs=b.ofs + b.tam2
  and c.tamanho=2

  update a set cc='CNPJBASE_B_F_D' from TempOfs a, TempOfs b, TempOfs c where 
      a.tamanho in (8,9,10) and b.id=a.id and ( b.ofs=a.ofs + a.tamanho+1 or b.ofs=a.ofs + a.tam2+1 )
  and b.tamanho=4 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=2 

  update b set cc='CNPJFILIAL' from TempOfs a, TempOfs b, TempOfs c where 
      a.tamanho in (8,9,10) and b.id=a.id and ( b.ofs=a.ofs + a.tamanho+1 or b.ofs=a.ofs + a.tam2+1 )
  and b.tamanho=4 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=2 

  update c set cc='CNPJDAC' from TempOfs a, TempOfs b, TempOfs c where 
      a.tamanho in (8,9,10) and b.id=a.id and ( b.ofs=a.ofs + a.tamanho+1 or b.ofs=a.ofs + a.tam2+1 )
  and b.tamanho=4 and c.id=a.id and c.ofs=b.ofs + b.tamanho+1
  and c.tamanho=2 

  update a set cc='CPFZEROS' from TempOfs a, TempOfs b, TempOfs c where 
      a.tam2 in (4) and b.id=a.id and b.ofs=a.ofs + a.tam2
  and b.tamanho=9 and c.id=a.id and c.ofs=b.ofs + b.tam2
  and c.tamanho=2
  update b set cc='CPFBASE' from TempOfs a, TempOfs b, TempOfs c where 
      a.tam2 in (4) and b.id=a.id and b.ofs=a.ofs + a.tam2
  and b.tamanho=9 and c.id=a.id and c.ofs=b.ofs + b.tam2
  and c.tamanho=2
  update c set cc='CPFDAC' from TempOfs a, TempOfs b, TempOfs c where 
      a.tam2 in (4) and b.id=a.id and b.ofs=a.ofs + a.tam2
  and b.tamanho=9 and c.id=a.id and c.ofs=b.ofs + b.tam2
  and c.tamanho=2

  update a set cc='CNPJBASE' from TempMain a where a.tamanho in (8,9) and a.nome like '%CGC%' and nome not like '%CPF%' and cc is null
  update a set cc='CNPJBASE' from TempMain a where a.tamanho in (8,9) and a.nome like '%CNPJ%' and nome not like '%CPF%' and cc is null
  update a set cc='CPFBASE' from TempMain a where a.tamanho in (9) and a.nome not like '%CGC%' and nome like '%CPF%' and cc is null

  update a set cc='CNPJBASEFIL' from tempMain a where a.cc is null and a.maskedit like '%.%/9999'
  update a set cc='CNPJBASEFIL' from tempMain a where a.cc is null and a.maskedit like '%.%.9999'
  update a set cc='CNPJBASEFIL' from tempMain a where a.cc is null and a.maskedit like '%.%/ZZZZ'
  update a set cc='CNPJBASEFIL' from tempMain a where a.cc is null and a.maskedit like '%.%.ZZZZ'
  update a set cc='CNPJ' from tempMain a where a.cc is null and a.maskedit like '%.%/9999-99'
  update a set cc='CPF' from tempMain a where a.cc is null and a.maskedit like '%.%/99'
  update a set cc='CPF' from tempMain a where a.cc is null and a.maskedit like '%.%.99' and nome like '%cpf%'
  update a set cc='CPF' from tempMain a where a.cc is null and a.maskedit like '%.%.99bbbb' and nome like '%cpf%'
  --select * from tempMain a where a.cc is null and a.maskedit like '%.%'

  update b set cc='CNPJFILLER' from TempOfs a, tempOfs b where a.cc like 'CNPJFIL%' and b.id=a.id and b.ofs=a.ofs+a.tamanho and b.tamanho=1
  update b set cc='CNPJDAC'    from TempOfs a, tempOfs b where a.cc like 'CNPJFIL%' and b.id=a.id and b.ofs=a.ofs+a.tamanho and b.tamanho=2
  update b set cc='CNPJFILLER' from TempOfs a, tempOfs b where a.cc like 'CNPJBAS%' and b.id=a.id and b.ofs=a.ofs+a.tamanho and b.tamanho=1
  update b set cc='CPFFILLER'  from TempOfs a, tempOfs b where a.cc like 'CPFBAS%' and b.id=a.id and b.ofs=a.ofs+a.tamanho and b.tamanho=1

  update a set cc='CNPJ' from tempMain a, tempMain b where a.cc is null and a.tamanho in (14,15,17,18) and b.id=a.seq and b.cc like 'CNPJ%'
     and 1 not in ( select 1 from tempMain b where b.id=a.seq and b.cc like 'CPF%' )
  update a set cc='CNPJCPF' from tempMain a, tempMain b where a.cc is null and a.tamanho in (14,15,17,18) and b.id=a.seq and b.cc like 'CNPJ%'
     and 1 in ( select 1 from tempMain b where b.id=a.seq and b.cc like 'CPF%' )
  update a set cc='CPF' from tempMain a, tempMain b where a.cc is null and a.tamanho in (14,15,17,18) and b.id=a.seq and b.cc like 'CPF%'
     and 1 not in ( select 1 from tempMain b where b.id=a.seq and b.cc like 'CNPJ%' )

  update a set cc='CNPJ' 
    from tempMain a, tempMain b where a.cc is null and a.tamanho in (14,15,17,18) and b.classe like 'CNPJ%P0' and b.cc like 'CNPJBAS%' and a.classe=replace(b.classe,'_P0','')
     and 1 not in ( select 1 from tempMain b where b.id=a.seq and b.cc like 'CPF%' )

  update a set cc=replace(a.cc,'CNPJ','CPF') from tempMain a, TempMain b where a.cc='cnpjbase' and b.fonte=a.fonte and b.nome<>a.nome and b.cc=a.cc
    and a.nome like '%CPF%' and b.nome not like '%cpf%'
	and a.nome not like '%CGC%' and a.nome not like '%cnp%'
	and a.classe=b.classe
  update a set cc=replace(a.cc,'CNPJ','CPF') from tempMain a, TempMain b where a.cc='cnpj' and b.fonte=a.fonte and b.nome<>a.nome and b.cc=a.cc
    and a.nome like '%CPF%' and b.nome not like '%cpf%'
	and a.nome not like '%CGC%' and a.nome not like '%cnp%'
	and a.classe=b.classe

  update b set cc=replace(replace(a.cc,'CNPJBASE1_','CNPJ ('),'CNPJBASE_','CNPJ (')+')' from tempMain a, tempMain b where a.cc like 'CNPJBASE%' and charindex('_',a.cc)>charindex('BASE',a.cc)
     and b.seq=a.id

  update a set cc=null from tempMain a where a.nome like 'BCO%' and cc like '%CNPJ%'
  update a set cc=null from tempMain a where a.nome like 'dt%' and cc like '%CNPJ%'
  update a set cc=null from tempMain a where a.nome like 'dat%' and cc like '%CNPJ%'
  update a set cc=null from tempMain a where a.nome like 'hr%' and cc like '%CNPJ%'

  exec limpacc 'CNPJ_0:14_14:4'
  exec limpacc 'CNPJ_0:4_4:14'

  update TempMain set impacto=''
  update a set impacto='CPF' from TempMain a where cc like 'CPF%' and nome not like 'FILL%'
  update a set impacto='PROGRAMAS' from TempMain a where a.impacto=''
    and 1 in ( select 1 from TB_PROGRAMAS where nome=a.fonte )
  update a set impacto='BOOK100' from TempMain a where a.impacto=''
    and 1 in ( select 1 from TB_INCLUDES where nome=a.fonte )
	and fonte in ( select fonte from tempMain where cc is not null group by fonte having count(*)>100 )
  update a set impacto='BOOK50' from TempMain a where a.impacto=''
    and 1 in ( select 1 from TB_INCLUDES where nome=a.fonte )
	and fonte in ( select fonte from tempMain where cc is not null group by fonte having count(*)>10 )
  update a set impacto='BOOKS' from TempMain a where a.impacto=''
    and 1 in ( select 1 from TB_INCLUDES where nome=a.fonte )

  delete a	    
	from TempMain a, TB_VARIAVEIS a1, TB_VARIAVEIS b where a.tipo='G' and a.ate>0 and a.fonte=a1.fonte and a.nome=a1.nome
     and b.programa=a1.PROGRAMA and b.OFFSET>=a1.OFFSET and b.OFFSET<a1.OFFSET+a1.TAMANHO and b.LINHAFONTE between a.lin and a.ate
     and b.nome<>a.nome and b.FONTE=a1.FONTE
     and b.init like char(39)+'%'+char(39) 
		 and REPLACE(b.init,char(39),'')>'A'-- not in ( '.', '-', '/' )

  delete a
  --select a.*, b.OFFSET-a1.OFFSET, b.nome, B.*
	from TempMain a, TB_VARIAVEIS a1, TB_VARIAVEIS b where a.tipo='G' and a.ate>0 and a.fonte=a1.fonte and a.nome=a1.nome
     and b.programa=a1.PROGRAMA and b.OFFSET>=a1.OFFSET and b.OFFSET<a1.OFFSET+a1.TAMANHO and b.LINHAFONTE between a.lin and a.ate
     and b.nome<>a.nome and b.FONTE=a1.FONTE
     and b.FORMATO in ( 'p', 'b' ) 

  delete a
  --select a.*, b.OFFSET-a1.OFFSET, b.nome, B.*
	from TempMain a, TB_VARIAVEIS a1, TB_VARIAVEIS b where a.tipo='G' and a.ate>0 and a.fonte=a1.fonte and a.nome=a1.nome
     and b.programa=a1.PROGRAMA and b.OFFSET>=a1.OFFSET and b.OFFSET<a1.OFFSET+a1.TAMANHO and b.LINHAFONTE between a.lin and a.ate
     and b.nome<>a.nome and b.FONTE=a1.FONTE
     and b.TAMANHO=7

  update b set cc='DEL' FROM dcopy a, tempMain b where a.suffix like '%CGC%' and b.fonte=a.copy and b.nome like  '%-%'
     and reverse(substring(reverse(b.nome),charindex('-',reverse(b.nome))+1,255)) not like '%CGC%' 
     and reverse(substring(reverse(b.nome),charindex('-',reverse(b.nome))+1,255)) not like '%CNP%' 
     and cc not like '%PES%'

  delete from tempMain where nome='FILLER'
  --select * from TempMain a where classe not like 'cnpj%'

  --select distinct classe from tempMain
  insert into TempMain 
  select distinct 'Numbase_8', '', a.fonte, e.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), e.LINGUAGEM, 'NUMBASE', 0, a.nivel, a.linhafonte, 0, 'NUMBASE'
    from TB_VARIAVEIS a, TB_PROGRAMAS e where ( a.nome like '%CNPJ%' or a.nome like '%CGC%' )
     and area<>'2'
     and 1 not in ( select 1 from TempMain b where b.fonte=a.fonte and b.nome=a.nome )
     and tamanho=8
	 and e.nome=a.PROGRAMA and e.ext<>'PSB'

  insert into TempMain 
  select distinct 'Numbase', '', a.fonte, e.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), e.LINGUAGEM, 'NUMBASE', 0, a.nivel, a.linhafonte, 0, 'NUMBASE'
    from TB_VARIAVEIS a, TB_PROGRAMAS e where ( a.nome like '%-CNPJ%' or a.nome like '%-CGC%' or a.nome like '%CDCGC%' or a.nome like '%CDCNPJ%' or a.nome like '%NRO-CGC%' or a.nome like '%NRO-CNPJ%' or a.nome like '%NUCGC%' or a.nome like '%NUCNPJ%' )
     and area<>'2'
     and 1 not in ( select 1 from TempMain b where b.fonte=a.fonte and b.nome=a.nome )
     and tamanho IN ( 8, 9 )
	 and e.nome=a.PROGRAMA and e.ext<>'PSB'
	 and a.nome not like 'seracgc-%'

  insert into TempMain 
  select distinct 'Filial', '', c.fonte, e.ext, c.nome, c.tipo, c.FORMATO, c.TAMANHO, c.MASKEDIT, 'Vari�vel '+replace(c.fonte,'$',''), e.LINGUAGEM, 'FILIAL', 0, C.nivel, C.linhafonte, 0, 'FILIAL'
    from TempMain a, TB_VARIAVEIS b, TB_VARIAVEIS c, TB_PROGRAMAS e where a.cc like 'NUMBASE%' and b.fonte=a.fonte and b.nome=a.nome
     and c.programa=b.PROGRAMA and c.OFFSET=b.OFFSET+b.TAMANHOFIS and c.TAMANHO=4
     and 1 not in ( select 1 from TempMain b where b.fonte=c.fonte and b.nome=c.nome )
	 and c.nome like '%-F%'
	 and e.nome=c.PROGRAMA and e.ext<>'PSB'

  insert into TempMain 
  select distinct 'NumbaseTela', '', a.fonte, e.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), e.LINGUAGEM, 'NUMBASE', 0, a.nivel, a.linhafonte, 0, 'NUMBASE'
    from TB_VARIAVEIS a, TB_PROGRAMAS e where ( a.nome like 'M%CNPJ%' or a.nome like 'M%CGC%' ) and ( a.nome like '%I' or a.nome like '%O' )
	 and len(a.nome)<=9
     and area<>'2'
     and 1 not in ( select 1 from TempMain b where b.fonte=a.fonte and b.nome=a.nome )
     and tamanho IN ( 8, 9 )
	 and e.nome=a.PROGRAMA and e.ext<>'PSB'
	 and a.nome not like 'seracgc-%'

	 --select * from TempMain where filtro='NumbaseTela'

  insert into TempMain 
  select distinct 'FILIAL4', '', a.fonte, e.ext, a.nome, a.tipo, a.FORMATO, a.TAMANHO, a.MASKEDIT, 'Vari�vel '+replace(a.fonte,'$',''), e.LINGUAGEM, 'FILIAL', 0, a.nivel, a.linhafonte, 0, 'FILIAL'
    from TB_VARIAVEIS a, TB_PROGRAMAS E where ( a.nome like '%CNPJ%' or a.nome like '%CGC%' )
	 and ( a.nome like '%FIL%'
	    or a.nome like '%-FL%'
	    or a.nome like '%CNPJ4%' )
     and area<>'2'
     and 1 not in ( select 1 from tempMain b where b.FONTE=a.fonte and b.nome=a.nome )
	 and a.nome not like 'seracgc-%'
	 AND TAMANHO=4
	 and e.nome=a.PROGRAMA and e.ext<>'PSB'

  delete a from TempMain a where a.nome like '%-QT%'
  delete a from TempMain a where a.nome like '%-DT%'
  delete a from TempMain a where a.nome like '%-DAT%'

  --select * from TempMain a where a.nome like '%AX-REGP003-NUMCNPJLOJ-N%'
	 /*
     select * from TB_VARIAVEIS a where ( a.nome like '%CNPJ%' or a.nome like '%CGC%' )
     and area<>'2'
     --and 1 not in ( select 1 from tabimpact b where b.pai=a.fonte and b.objeto=a.nome )
     and 1 not in ( select 1 from TEMPMAIN b where b.FONTE=a.fonte and b.NOME=a.nome )
	 and a.nome not like 'seracgc-%'
	 AND TAMANHO between 4 and 15
     --and tamanho IN (8,9)
	 and nome not like '%-DAT%'
	 and nome not like '%-QT%'
	 and nome not like '%-TIP%'
	 and nome not like '%l'
	 and nome not like '%-logon%'
     order by programa, LINHAEXP

  select * from tempmain where nome like '%AX-REGCOM-CGC-N%'
  */
  truncate table tabimpact

  insert into tabimpact
  select distinct 'CPF', niv, seq, fonte, 99, nome, 0, 0, 'CPF '+tipo+' '+ltrim(str(tam)), -1 as modo, 0 as checar, -1,  'CPF' 
  from TempCpf where tam in (9, 11, 14) 
  order by niv, seq

  insert into tabimpact
  select distinct 'CPF', niv, seq, fonte, 99, nome, 0, 0, 'CPF '+tipo+' '+ltrim(str(tamanho)), -1 as modo, 0 as checar, -1,  'CPF' 
  from TempMain where classe like 'CPF%'
  order by niv, seq

  insert into tabimpact
  select distinct 'NUMBASE', 0, min(seq) as seq, fonte, 99, nome, 0, 0, 'NUMBASE ' + ltrim(str(tamanho)), -1 as modo, 1 as checar, -1,  'NUMBASE' 
  from tempMain where ext<>'DB2' and ( classe like 'num%' or classe like 'bas%' or cc like 'NUMBASE%' or cc like 'CNPJBASE%' ) and tamanho in ( 8, 9 ) 
  group by fonte, nome, tamanho
  order by seq

  insert into tabimpact
  select distinct 'BASEFIL', 0, min(seq) as seq, fonte, 99, nome, 0, 0, 'BASEFIL ' + ltrim(str(tamanho)), -1 as modo, 1 as checar, -1,  'BASEFIL' 
  from tempMain where ext<>'DB2' and ( classe like 'num%' or classe like 'bas%' ) and tamanho in ( 12, 13 ) 
  group by fonte, nome, tamanho
  order by seq

  insert into tabimpact
  select distinct 'CNPJ', 0, min(seq) as seq, fonte, 99, nome, 0, 0, 'CNPJ ' + ltrim(str(tamanho)), -1 as modo, 1 as checar, -1,  'CNPJ'
  from tempMain where ext<>'DB2' and classe not like 'filial%' and tamanho in ( 14, 15) and classe<>'?'
  group by fonte, nome, tamanho
  order by seq

  insert into tabimpact
  select distinct 'CNPJ', 0, min(seq) as seq, fonte, 99, nome, 0, 0, 'FILIAL' + ltrim(str(tamanho)), -1 as modo, 1 as checar, -1,  'FILIAL'
  --SELECT * 
  from tempMain where ext<>'DB2' and ( classe like 'filial%' or cc like 'fil%' ) and tamanho in ( 4 ) and classe<>'?'
    and nome like '%-FIL%'
    and nome like '%-FL%'
  group by fonte, nome, tamanho
  order by seq

  delete from tabimpact where objeto iN ( 'TOTAL-WCGCS', 'TOTAL-WCGC', 'EMBASA-WPXB', 
  'CPF21', 'CPF31',
  'CGCTR-16-MONT-LANC',
  'CGCTR-66B-CONTA',
  'QTDREGS-WCPF01E', 'BCO1-WCGCPF', 'BVB02RCD-DTLAN', 'BVB02CCI-DTLAN', 'WAUX-IDEMPTRA', 'PRINC-WCANTCGC', 'PRIN-WTABCRE1', 'IDPROPFI-WENT', 'GRAGNCTA', 'WAGCC2', 'WAGCC3' )

  update a set nomeimpacto='iCNPJ' from tabimpact a where nomeimpacto not in ('', 'CPF')

  delete from tabimpact where objeto='FILLER'
  delete from tabimpact where objeto like '%FONE%'

  update tabimpact set NOMEIMPACTO='CNPJSer' where NOMEIMPACTO='iCNPJ'
  update tabimpact set nivel=0, checar=1, seq=seq+(select max(seq) from TABIMPACT where NOMEIMPACTO='cnpjser') where NOMEIMPACTO='CPF'
  update tabimpact set NOMEIMPACTO='CNPJSer', CLASSE='CPF' where NOMEIMPACTO='CPF'
end
--go

--exec #ImpactoMapearMainframeSementes

--select * from TempCpf
--select * from impactResults
