create proc #iMappCPF as
begin
  if exists ( select 1 from sysobjects where name='TempCPF' )
    drop table TempCpf  
    
  create table TempCpf (
    seq   integer identity,
    niv   int,
    fonte varchar(80),
    lin   integer,
    nome  varchar(255),
    tipo  char,
    form  char,
    tam   int
  )

  create index ix1 on TempCpf ( fonte, lin )
  create index ix2 on TempCpf ( nome, fonte )
  
  declare @qtd int
  
  insert into TempCpf
  select distinct 1, a.fonte, a.LINHAFONTE, a.nome, a.tipo, a.formato, a.TAMANHO from TB_VARIAVEIS a where 
  a.TAMANHO=11 and a.tipo not in ( '2' ) and a.area not in ( '2' )
  and a.nome like '%CPF%' 
  and 1 not in ( select 1 from TempCpf where fonte=a.fonte and nome=a.nome )
  
  set @qtd = @@ROWCOUNT
  
  -- MASCARA DE EDICAO 999.999.999
  insert into TempCpf
  select distinct 1, a.fonte, a.LINHAFONTE, a.nome, a.tipo, a.formato, a.TAMANHO from TB_VARIAVEIS a where 
  a.TAMANHO=9 and a.tamanhofis=11 and a.tipo not in ( '2' ) and a.area not in ( '2' )
  and a.nome like '%CPF%' 
  and 1 not in ( select 1 from TempCpf where fonte=a.fonte and nome=a.nome )
  
  set @qtd = @@ROWCOUNT
  
  insert into TempCpf
  select distinct 1, c.fonte, c.LINHAFONTE, c.nome, c.tipo, c.formato, c.TAMANHO 
  from TempCpf a, TB_VARIAVEIS b, TB_VARIAVEIS c where a.tam=11
  and b.fonte=a.fonte and b.nome=a.nome
  and c.programa=b.programa and c.OFFSET=b.OFFSET+0 and c.TAMANHO=9 --and c.LINHAEXP>b.LINHAEXP
  and c.nome like '%CPF%' 
  and c.tipo not in ( '2' ) and c.area not in ( '2' )
  and 1 not in ( select 1 from TempCpf where fonte=c.fonte and nome=c.nome )
  
  set @qtd = @qtd + @@ROWCOUNT
  
  insert into TempCpf
  select distinct 1, b.fonte, b.LINHAFONTE, b.nome, b.tipo, b.formato, b.TAMANHO 
  from TB_VARIAVEIS a, TB_VARIAVEIS b where 
  a.TIPO='G' and a.TAMANHO=11 and b.tipo not in ( '2' ) and b.area not in ( '2' )
  and b.PROGRAMA=a.PROGRAMA and b.OFFSET=a.OFFSET and b.TAMANHO=9 and b.LINHAEXP>a.LINHAEXP
  and b.nome like '%CPF%' 
  and 1 not in ( select 1 from TempCpf where fonte=b.fonte and nome=b.nome )
  
  set @qtd = @qtd + @@ROWCOUNT
  
  insert into TempCpf
  select distinct 1, a.fonte, a.LINHAFONTE, a.nome, a.tipo, a.formato, a.TAMANHO from TB_VARIAVEIS a where 
  a.TAMANHO=14 and a.tipo not in ( '2' ) and a.area not in ( '2' )
  and a.nome like '%CPF%' and a.nome not like '%CGC%'  and a.nome not like '%CNP%' 
  --and 1 not in ( select 1 from TempCpf where fonte=a.fonte and nome=a.nome )
  
  set @qtd = @@ROWCOUNT
  
  insert into TempCpf
  select distinct 1, c.fonte, c.LINHAFONTE, c.nome, c.tipo, c.formato, c.TAMANHO 
  from TempCpf a, TB_VARIAVEIS b, TB_VARIAVEIS c where a.tam=14
  and b.fonte=a.fonte and b.nome=a.nome
  and c.programa=b.programa and c.OFFSET=b.OFFSET+3 and c.TAMANHO=9 --and c.LINHAEXP>b.LINHAEXP
  and c.nome like '%CPF%' 
  and c.tipo not in ( '2' ) and c.area not in ( '2' )
  and 1 not in ( select 1 from TempCpf where fonte=c.fonte and nome=c.nome )
  
  set @qtd = @qtd + @@ROWCOUNT
  
  insert into TempCpf
  select distinct 1, b.fonte, b.LINHAFONTE, b.nome, b.tipo, b.formato, b.TAMANHO from TB_VARIAVEIS a, TB_VARIAVEIS b where 
  a.TIPO='G' and a.TAMANHO=14 
  and b.PROGRAMA=a.PROGRAMA and b.OFFSET=a.OFFSET+3 and b.TAMANHO=9 and b.LINHAEXP>a.LINHAEXP
  and b.nome like '%CPF%' and b.nome not like '%CGC%'  and b.nome not like '%CNP%'
  and b.tipo not in ( '2' ) and b.area not in ( '2' )
  and 1 not in ( select 1 from TempCpf where fonte=b.fonte and nome=b.nome )
  
  set @qtd = @qtd + @@ROWCOUNT
  
  insert into TempCpf
  select distinct 1, a.fonte, a.LINHAFONTE, a.nome, a.tipo, a.formato, a.TAMANHO from TB_VARIAVEIS a, TB_VARIAVEIS b where 
  a.TAMANHO=9 and a.nome like '%CPF%' and a.tipo not in ( '2' ) and a.area not in ( '2' )
  and b.programa=a.PROGRAMA and b.OFFSET=a.OFFSET+a.TAMANHO and b.TAMANHO=2
  and 1 not in ( select 1 from TempCpf where fonte=a.fonte and nome=a.nome )
  
  set @qtd = @qtd + @@ROWCOUNT
  
  insert into TempCpf
  select distinct 1, a.fonte, a.LINHAFONTE, a.nome, a.tipo, a.formato, a.TAMANHO from TB_VARIAVEIS a, TB_VARIAVEIS b, TB_VARIAVEIS c where 
  a.TAMANHO=9 and a.nome like '%CPF%' and a.nome not like '%CGC%'
  and a.tipo not in ( '2' ) and a.area not in ( '2' ) and a.FORMATO not in ('b','p' )
  and b.programa=a.PROGRAMA and b.OFFSET=a.OFFSET+a.TAMANHO+1 and b.TAMANHO=2
  and c.programa=a.PROGRAMA and c.OFFSET=a.OFFSET+a.TAMANHO+0 and c.TAMANHO=1
  and 1 not in ( select 1 from TempCpf where fonte=a.fonte and nome=a.nome )
  
  set @qtd = @qtd + @@ROWCOUNT
  
  insert into TempCpf
  select distinct 1, a.fonte, a.LINHAFONTE, a.nome, a.tipo, a.formato, a.TAMANHO from TB_VARIAVEIS a where 
  a.TAMANHO=9 and 
  a.tipo not in ( '2' ) and a.area not in ( '2' ) and a.FORMATO not in ( 'b' )
  and a.nome like '%CPF%' and a.nome not like '%CGC%'  and a.nome not like '%CNP%' 
  and 1 not in ( select 1 from TempCpf where fonte=a.fonte and nome=a.nome )
  
  set @qtd = @@ROWCOUNT
  
  --select * from tempcpf
  --select distinct tipo, form, tam from tempcpf
  
  declare @niv int
  --declare @qtd int
  set @qtd = 1
  set @niv = 1
  
  while @qtd > 0
  begin
  	insert into TempCpf
  		select min(@niv+1), d.fonte, min(d.LINHAFONTE), d.nome, d.tipo, d.formato, d.TAMANHO 
  		from TempCpf a, TB_VARIAVEIS b, TB_VARVAR c, TB_VARIAVEIS d
  		where a.niv=@niv and a.fonte=b.fonte and a.lin=b.LINHAFONTE and a.tam in ( 9, 11, 14 )
  		and c.PROGRAMA=b.PROGRAMA and c.vr1=b.nome and c.linvr2>0
  		and d.programa=c.PROGRAMA and d.LINHAEXP=linvr2 and d.TAMANHO=a.tam
  		and 1 not in ( select 1 from TempCpf where fonte=d.fonte and nome=d.nome )
  		and d.nome like '%CPF%'
  		and ( d.tamanho=11 or ( d.nome not like '%CGC%' and d.nome not like '%CNP%' ) )
  		and d.tipo not in ( '2' ) and d.area not in ( '2' )
  		group by d.fonte, d.nome, d.tipo, d.formato, d.TAMANHO 
  	set @qtd = @@ROWCOUNT
  	insert into TempCpf
  		select min(@niv+1), d.fonte, MIN(d.LINHAFONTE), d.nome, d.tipo, d.formato, d.TAMANHO 
  		from TempCpf a, TB_VARIAVEIS b, TB_VARVAR c, TB_VARIAVEIS d
  		where a.niv=@niv and a.fonte=b.fonte and a.lin=b.LINHAFONTE and a.tam in ( 9, 11, 14 )
  		and c.PROGRAMA=b.PROGRAMA and c.vr2=b.nome and c.linvr1>0
  		and d.programa=c.PROGRAMA and d.LINHAEXP=linvr1 and d.TAMANHO=a.tam
  		and 1 not in ( select 1 from TempCpf where fonte=d.fonte and nome=d.nome )
  		and d.nome like '%CPF%'
  		and ( d.tamanho=11 or ( d.nome not like '%CGC%' and d.nome not like '%CNP%' ) )
  		and d.tipo not in ( '2' ) and d.area not in ( '2' )
  		group by d.fonte, d.nome, d.tipo, d.formato, d.TAMANHO 
  	set @qtd = @qtd + @@ROWCOUNT
  	insert into TempCpf
  		select min(@niv+1), d.fonte, MIN(d.LINHAFONTE), d.nome, d.tipo, d.formato, d.TAMANHO 
  		from TempCpf a, TB_VARIAVEIS b, TB_VARIAVEIS d
  		where a.niv=@niv and a.fonte=b.fonte and a.lin=b.LINHAFONTE and a.tam in ( 9, 11, 14 )
  		and d.programa=b.PROGRAMA and d.OFFSET=b.OFFSET and d.TAMANHO=a.tam
  		and 1 not in ( select 1 from TempCpf where fonte=d.fonte and nome=d.nome )
  		and d.nome like '%CPF%'
  		and ( d.tamanho=11 or ( d.nome not like '%CGC%' and d.nome not like '%CNP%' ) )
  		and d.tipo not in ( '2' ) and d.area not in ( '2' )
  		group by d.fonte, d.nome, d.tipo, d.formato, d.TAMANHO 
  	set @qtd = @qtd + @@ROWCOUNT
  	set @niv = @niv + 1
  end
end
--go

--exec #iMappCPF 

