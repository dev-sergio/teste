--drop proc #passo9E_inventariar 
--go
create proc #passo9E_inventariar as
begin

update a set ddname=replace(ddname,char(39),'') from TB_IOAREA a where ddname like char(39)+'%'+char(39) and cobname='linkage'
--select * from RL_labels a where a.TIPO_OBJETO=9 and a.TIPO_RELACAO='p' and objeto like char(39)+'%'+char(39)

delete from RL_MODULOS where origem='@INVENTARIO'

insert into RL_MODULOS 
select distinct objeto, min(origem) as ref, 10, 10, 'P', 1, '@INVENTARIO' from TB_REGISTRO where DESCRICAO like 'book fa%' group by objeto

insert into RL_MODULOS 
select objeto, min(chave) as ref, 9, 9, 'P', 1, '@INVENTARIO' from RL_PROGRAMAS a where a.TIPO_OBJETO='9' and objeto not like '%-%' 
and objeto not in ( 'aibtdli', 'cbltdli', 'dsntiar' )
and 1 not in ( select 1 from TB_INVENTARIO where fonte=a.objeto ) group by objeto order by replace(objeto,'$','')

insert into RL_MODULOS 
select modname, min(programa) as ref, 14, 14, 'P', 1, '@INVENTARIO' from imsacessos a where a.modname<>'' AND ACESSO<>'CHNG'
and a.modname not in ( select msginp from imsmapas )
and a.modname not in ( select msgout from imsmapas )
and a.modname not in ( 'EABLMR', 'GRMENS' )
group by modname

insert into RL_MODULOS 
select ddname, min(programa) as ref, 11, 1109, 'P', 1, '@INVENTARIO' from TB_ARQUIVOS a where a.tipo in ( 4 )
and 1 not in ( select top 1 1 from TB_VARIAVEIS where programa='tabledb2' and REDEFINES=ddname )
group by ddname

update a set SUBTIPO=903 from RL_MODULOS a where origem='@INVENTARIO' and TIPO_OBJETO=9 and chave like '$%'

--select * from RL_MODULOS where origem='@INVENTARIO'

if exists ( select 1 from sysobjects where name='tdInv' )
   drop table tdInv
--go

create table tdInv (
  sigla varchar(20),
  nome varchar(255),
  ext varchar(3),
  linguagem varchar(255),
  tipo int,
  linhas int,
  brancos int,
  comments int,
  bytes int,
  checksum int,
  dth datetime
)

create index ix0 on tdInv ( nome, tipo )
create index ix1 on tdInv ( sigla, nome )
--go

insert into tdInv
select rtrim(siglasis), nome, Upper(ext), linguagem, 0, linhas, brancos, comment, 0, 0, null from TB_PROGRAMAS
insert into tdInv
select rtrim(siglasis), nome, Upper(ext), ext, 0, 0, 0, 0, 0, 0, null from TB_rotinas
insert into tdInv
select 'Books', fonte, Upper(extensao), extensao, 0, 0, 0, 0, 0, 0, null from TB_INVENTARIO WHERE EXTENSAO in ('CPY','inc')

update a set checksum=b.CHECKSUM, linhas=b.LINHA, dth=b.DTH, bytes=b.BYTES from tdInv a, TB_INVENTARIO b where a.nome=b.FONTE and a.ext=b.EXTENSAO

update a set sigla='Subrotinas Ita�' from tdInv a, tdSubItau b where a.nome=b.NOME

update a set linguagem='Cobol' from tdInv a where a.ext='cbl'
update a set linguagem='Assembler' from tdInv a where a.ext='mac'
update a set linguagem='DB2 DDL' from tdInv a where a.ext='ddl'
update a set linguagem='Tela IMS' from tdInv a where a.ext='MFS'
update a set linguagem='Tela CICS' from tdInv a where a.ext='BMS'
update a set linguagem='Job' from tdInv a where a.ext='jco'
update a set linguagem='Procedure' from tdInv a where a.ext='jcl'
update a set linguagem='Copy Cobol' from tdInv a where a.ext='cpy'
update a set linguagem='Include' from tdInv a where a.ext='inc'
update a set linguagem='Natural' from tdInv a where a.ext='nat'
update a set linguagem='Natural Subr' from tdInv a where a.ext='nss'
update a set linguagem='Natural Subp' from tdInv a where a.ext='nsn'
update a set linguagem='Natural Help' from tdInv a where a.ext='nsh'
update a set linguagem='Tela Natural' from tdInv a where a.ext='nsm'

update a set comments=(select count(*) from TB_COMMENT b where b.fonte=a.nome and b.ext=a.ext ) from tdInv a where a.ext in ( 'jco', 'jcl' )
update a set comments=(select count(*) from TB_fonte b where b.fonte=a.nome and b.ext=a.ext and texto like '--%' ) from tdInv a where a.ext in ( 'ddl' )
update a set comments=(select count(*) from TB_fonte b where b.fonte=a.nome and b.ext=a.ext and texto like '*%' ) from tdInv a where a.ext in ( 'mac', 'mfs', 'bms', 'nsm' )
update a set brancos=(select count(*) from TB_fonte b where b.fonte=a.nome and b.ext=a.ext and texto='' ) from tdInv a where a.ext not in ( 'cbl', 'nat', 'nss', 'nsn', 'nsh' )

update a set sigla=substring(nome,2,2) from tdInv a where a.nome like '$%' and sigla not like 'subro%'

--select * from tdinv
--go

drop table if exists tdTreePgm
create table tdTreePgm (
    id  integer identity,
	par int,
    niv int,
	ini varchar(255),
	pgm varchar(255),
	fnt varchar(255),
  )
create index ix1 on  tdTreePgm ( ini, niv )
--go

-- @ mapear telas
-- @ mapear IMS
-- metricas sistemas
-- metricas sistemas dados
-- rotinas x metodos

if exists ( select 1 from sysobjects where name='tdCat' )
   drop table tdCat
--go

create table tdCat (
  sigla varchar(30),
  nome varchar(255),
  ext varchar(3),
  tipo int,
  linhas int,
  brancos int,
  comments int,
  qtdsections int,
  linsemuso int,
  qtdcop int,
  qtdtab int,
  qtdsub int,
  qtdsubtree int,
  qtdtel int,
  qtdcam int,
  plataf varchar(255),
  databas varchar(30),
  recursos varchar(255),
  checksum int,
  codcpx int,
  funcpx int,
  fator int,
  cpx varchar(20)
)

create index ix0 on tdCat ( nome, tipo )
create index ix1 on tdCat ( sigla, nome )
--go

--select * from tb_functionpoints

insert into tdCat
select siglasis, nome, ext, (case when ext in ( 'CBL','NAT', 'NSS', 'NSN', 'NSH' ) then 9 else 14 end), linhas, BRANCOS, COMMENT, 0, 0, 0, 0, 0, 0, 0, 0, '', '', '', 0, 0, 0, 0, ''
from TB_PROGRAMAS where ext in ( 'CBL', 'MFS', 'BMS', 'NAT', 'NSS', 'NSN', 'NSM', 'NSH' )

declare @pgm varchar(255)
declare c1 cursor for select nome from tdCat where tipo=9
open c1
fetch c1 into @pgm
while @@FETCH_STATUS=0
  begin 
    exec buildtreepgm @pgm, 0
    fetch c1 into @pgm
  end
close c1
deallocate c1

update a set qtdsubtree=(select count(*)-1 from tdTreePgm where ini=a.nome) from tdcat a where a.tipo=9

update a set checksum=b.CHECKSUM from tdCat a, TB_INVENTARIO b where b.fonte=a.nome and b.EXTENSAO=a.ext

update a set codcpx=b.pto from tdCat a, TB_metrica b where b.pgm=a.nome 
update a set funcpx=b.pontos from tdCat a, tb_functionpoints b where b.nome=a.nome 

update a set qtdcam=(select count(*) from MAPFIELD b where b.E_GRPNAME=a.nome and b.e_tipo='V')
from tdCat a where a.tipo=14

update a set qtdcam=qtdcam+(
select count(*) from TB_ACTIONS b, TB_ACTARGS c, TB_VARIAVEIS d, TB_VARIAVEIS e where b.programa=a.nome and b.ACTION='json' and c.ACTION_ID=b.ACTION_ID and c.CLASSINFO in ( 'INTO_ARG', 'FROM_ARG' )
and d.programa=b.programa and d.nome=c.OBJECT and e.programa=d.PROGRAMA and e.OFFSET>=d.OFFSET and e.OFFSET<d.OFFSET+d.TAMANHO and e.TIPO in ( '9', 'X' )
) from tdcat a

update a set qtdcam=qtdcam+(
select count(distinct(e.nome)) from TB_VARIAVEIS d, TB_VARIAVEIS e where d.programa=a.nome and d.area='l' and 
d.nome not like '%pcb%' and e.programa=d.PROGRAMA and e.OFFSET>=d.OFFSET and e.OFFSET<d.OFFSET+d.TAMANHO and e.TIPO in ( '9', 'X' )
) from tdcat a

--select * from TB_VARIAVEIS where area='l'

update a set qtdsections=(select count(*) from tb_Labels b, TB_FONTE c where b.PROGRAMA=a.nome and c.fonte=b.PROGRAMA and c.LINHAEXP=b.LINHAEXP and c.texto like '% SECTION%')
from tdCat a where a.tipo=9

update a set qtdcop=(select count(*) from RL_PROGRAMAS b where b.chave=a.nome and b.TIPO_OBJETO=10 and len(objeto)<=8 )
from tdCat a where a.tipo=9

update a set qtdtab=(select count(distinct(ddname)) from TB_ARQUIVOS b where b.programa=a.nome and tipo in (4, 128 ) )
from tdCat a where a.tipo=9

update a set qtdsub=(select count(distinct(objeto)) from RL_PROGRAMAS b where b.chave=a.nome and b.TIPO_OBJETO=9 and b.TIPO_RELACAO='P' )
from tdCat a where a.tipo=9

update a set qtdtel=(select count(distinct(mapa)) from tdMapIO b where b.programa=a.nome and b.mapa<>'' )
from tdCat a where a.tipo=9

update a set qtdcam=qtdcam+(select count(distinct(b.mapa+c.campo)) from tdMapIO b, tdMapFields c where b.programa=a.nome and b.mapa<>'' and c.mapa=b.mapa and c.tipo='V')
from tdCat a where a.tipo=9

update a set recursos=ltrim(recursos+' PAG') from tdCat a, tdMapIO b, tdMapFields c where a.tipo=9 and b.programa=a.nome and b.mapa<>'' and c.mapa=b.mapa and c.tipo='V'
and c.indarr<>''

update z set plataf='APS' from tdcat z, tb_variaveis a, tdDicionario b where z.nome=a.programa and a.nome='APS-WS-HEADER' and b.nome=a.PROGRAMA and b.tecno<>'APS'
update z set plataf='CSP/VAGEN' 
from tdcat z, tb_variaveis a, tdDicionario b where z.nome=a.programa and a.nome like 'EZEAPP-APPL-NAME' and b.nome=a.PROGRAMA and b.tecno<>'CSP/VAGEN'
update z set plataf='TELON' from tdcat z, tb_variaveis a, tdDicionario b where z.nome=a.programa and a.nome='WORKFLD-ALPHA' and b.nome=a.PROGRAMA and b.tecno<>'TELON'

update a set plataf=ltrim(plataf+' BATCH') from tdCat a, TB_JCLSTEP b where a.nome=b.PROGRAMA and plataf=''
update a set plataf=ltrim(plataf+' CICS') from tdCat a, TB_VARVAR b where a.nome=b.PROGRAMA and b.acao='CICS' and plataf=''
update a set plataf=ltrim(plataf+' IMS') from tdCat a, TB_IOAREA b where a.nome=b.PROGRAMA and b.DDNAME='CBLTDLI' and plataf=''
update a set plataf=ltrim(a.plataf+' SUB '+c.plataf) from tdCat a, RL_PROGRAMAS b, tdCat c where a.plataf='' and b.OBJETO=a.nome and b.TIPO_OBJETO=9 and b.TIPO_RELACAO='P' and c.nome=b.chave and c.plataf<>''
update a set plataf=ltrim(plataf+' SUB ') from tdCat a, RL_PROGRAMAS b where a.plataf='' and b.OBJETO=a.nome and b.TIPO_OBJETO=9 and b.TIPO_RELACAO='P' 

--select * from tdCat a where a.plataf='' and ext not in ( 'BMS', 'MFS' )

update a set recursos=ltrim(recursos+' EA') from tdCat a, tb_varvar b where a.nome=b.programa and b.vr2 like char(39)+'%'+char(39) and replace(vr2,char(39),'') in ( 'LSOII', 'LCIC', 'CICS', 'SOII' )
update b set recursos=ltrim(recursos+' EA') from RL_PROGRAMAS a, tdCat b where objeto='COMPACK' and chave=nome and recursos not like '%EA%'

update a set recursos=ltrim(recursos+' GRBE') from tdCat a, RL_PROGRAMAS b where a.nome=b.chave and b.OBJETO='MONITOR'

update a set recursos=ltrim(recursos+' Servi�o') from tdCat a, RL_PROGRAMAS b where a.nome=b.chave and b.OBJETO like '%ZZ' and b.TIPO_OBJETO=9
update a set databas=ltrim(databas+' DB2') from tdCat a, TB_ARQUIVOS b where a.nome=b.programa and b.tipo in (4,128)
update a set databas=ltrim(databas+' SEQ') from tdCat a, TB_ARQUIVOS b where a.nome=b.programa and b.tipo in (1)
update a set databas=ltrim(databas+' VSAM') from tdCat a, TB_ARQUIVOS b where a.nome=b.programa and b.tipo in (2)
update a set databas=ltrim(databas+' '+ddname ) from tdCat a, TB_ARQUIVOS b where a.nome=b.programa and b.tipo in (8) and ddname in ( 'TS', 'TD', 'QUEUE', 'QNAME', '' ) 
update a set databas=ltrim(databas+' RRDS') from tdCat a, TB_ARQUIVOS b where a.nome=b.programa and b.tipo in (8) and ddname not in ( 'TS', 'TD', 'QUEUE', 'QNAME' )
update a set databas=ltrim(databas+' SORT') from tdCat a, TB_ARQUIVOS b where a.nome=b.programa and b.tipo in (16)
update a set databas=ltrim(databas+' RELATORIO') from tdCat a, TB_ARQUIVOS b where a.nome=b.programa and b.tipo in (32)
update a set databas=ltrim(databas+' RELATORIO') from tdCat a, TB_ARQUIVOS b, TB_JCLSTEP c where a.nome=b.programa and b.COMANDOS=2
and c.programa=b.PROGRAMA and c.DDNAME=b.DDNAME and c.LRECL=144

update a set linsemuso=(select sum(flinexp-linexp+1) from tdLabels b where b.programa=a.nome and b.tplab='section' and b.ref='') from tdCat a where tipo=9
and 1 in (select 1 from tdLabels b where b.programa=a.nome and b.tplab='section' and b.ref='') 

--update a set fator=round((0.2*(linhas-brancos-comments-linsemuso)*5)/120,0) from tdCat a where tipo=9
--update a set fator=1 from tdCat a where tipo=9 and fator=0
update a set funcpx=b.pontos from tdCat a, tb_functionpoints b where a.nome=b.nome 
update a set funcpx=funcpx+(select sum(pontos) from tb_functionpoints b where b.pgm=a.nome)from tdCat a where tipo=9
and 1 in (select 1 from tb_functionpoints b where b.pgm=a.nome)
--update a set fator=round(fator*codcpx*1.0/80,0) from tdCat a where tipo=9 and codcpx*1.0/80>1
--update a set fator=fator+round(0.2*(funcpx*5.0*0.65),0) from tdCat a where tipo=9

--SELECT * FROM TB_ARQUIVOS WHERE PARENT LIKE '%GRBE%'

update a set fator=funcpx/8+(case when funcpx%8>0 then 1 else 0 end) from tdCat a where tipo=9
update a set fator=round(fator+fator*(0.08*(codcpx/100)),0) from tdCat a where tipo=9 and codcpx>100
update a set fator=fator+2 from tdCat a where tipo=9 and recursos like '%EA%'
update a set fator=fator+2 from tdCat a where tipo=9 and recursos like '%PAG%'
--update a set fator=fator+(linhas/1000) from tdCat a where tipo=9 and linhas>1000

update a set cpx=(case when fator<=1 then '1-Simples' when fator<=2 then '2-Facil' when fator<=4 then '3-Media' when fator<=6 then '4-Dificil' else '5-Complexa' end), fator=fator*8 from tdCat a where tipo=9

update c set programa=substring(ltrim(substring(texto,charindex('&db2',b.texto)+4,255)),1,charindex(' ',ltrim(substring(texto,charindex('&db2',b.texto)+4,255)) +' ')-1) 
from TB_JCLSTEP a, tb_fonte b, tb_jclstep c where a.ACCT like 'ikjeft%' and a.programa='' 
 and b.fonte=a.jcl and b.LINFONTE in (a.nrolin, a.NROLIN+1)and b.texto like '%parm=%runprog%'
 and c.jcl=a.JCL and c.ORDEM=a.ORDEM

--select * from tdCat a where tipo=9
--select * from tdCat a where tipo=9 and databas like '%RELA%'
--insert into  tdObservac
--select distinct '', chave, 'DSNTIAR' from RL_PROGRAMAS a where a.objeto like '%DSNTIAR'
--insert into  tdObservacoes
--select distinct a.chave, 'Uso de subrotina corporativa ' + objeto from RL_PROGRAMAS a, tdSubItau b where a.TIPO_RELACAO='P' and a.TIPO_OBJETO=9 and a.OBJETO=b.NOME
--insert into  tdObservacoes
--select distinct a.chave, 'Uso de subrotina corporativa ' + objeto from RL_PROGRAMAS a, tdSubItau b where a.TIPO_RELACAO='P' and a.TIPO_OBJETO=9 and '$'+a.OBJETO=b.NOME

/*
select * from tdCat a where a.tipo=9
select * from tdMapas
select * from tdMapIO
select * from tdMapFields
select * from imsacessos a
select * from tb_metrica
select * from tb_fpa
*/

--select * from tdMetInfo
end

--go
--exec #passo9E_inventariar 

