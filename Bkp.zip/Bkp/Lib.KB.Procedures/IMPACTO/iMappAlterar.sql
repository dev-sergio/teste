--drop proc iMappAlterar
--go

create proc #iMappAlterar as 
begin

  if exists ( select 1 from syscolumns a, sysobjects b where a.name='dscAlter' and a.id=b.id and b.name='tb_texto' )
    alter table tb_texto drop column dscAlter

  alter table tb_texto add dscalter varchar(2048)

  if exists ( select 1 from syscolumns a, sysobjects b where a.name='tipo1' and a.id=b.id and b.name='tb_varvar' )
    begin
      alter table tb_varvar drop column tipo1
      alter table tb_varvar drop column tam1 
      alter table tb_varvar drop column tipo2 
      alter table tb_varvar drop column tam2 
      alter table tb_varvar drop column actype
      alter table tb_varvar drop column actimp
      alter table tb_varvar drop column var1
      alter table tb_varvar drop column pic1
      alter table tb_varvar drop column newpic1
      alter table tb_varvar drop column var2
      alter table tb_varvar drop column pic2
      alter table tb_varvar drop column newpic2
      alter table tb_varvar drop column l1
      alter table tb_varvar drop column l2
    end
  
  alter table tb_varvar add tipo1 varchar(8)
  alter table tb_varvar add tam1 int
  alter table tb_varvar add tipo2 varchar(8)
  alter table tb_varvar add tam2 int
  alter table tb_varvar add actimp varchar(255)
  alter table tb_varvar add actype varchar(255)
  alter table tb_varvar add var1 varchar(255)
  alter table tb_varvar add pic1 varchar(255)
  alter table tb_varvar add newpic1 varchar(255)
  alter table tb_varvar add var2 varchar(255)
  alter table tb_varvar add pic2 varchar(255)
  alter table tb_varvar add newpic2 varchar(255)
  alter table tb_varvar add l1 int
  alter table tb_varvar add l2 int

  /*  
  if exists ( select 1 from syscolumns a, sysobjects b where a.name='altera' and a.id=b.id and b.name='impactResults' )
    begin
      alter table impactResults drop column altera
      alter table impactResults drop column value
      alter table impactResults drop column linpic 
      alter table impactResults drop column linval 
	  alter table impactResults drop column dscAlter
    end
  
  alter table impactResults add altera varchar(255)
  alter table impactResults add value varchar(255)
  alter table impactResults add linpic int
  alter table impactResults add linval int
  alter table impactResults add dscalter varchar(2048)
  */
  --update impactResults set altera=null
  
  update tb_texto set tag=null, txtconv=null where tag is not null
  
--select * from impactResults where programa='JP5A5'
  update a set fmt=
  substring(texto,charindex(fmt,b.texto),255)
  from impactResults a, TB_FONTE b where form<>'' and a.tipo<>'G' and b.COPY=a.fonte and b.LINFONTE=a.linfon 
  and CHARINDEX(a.nome,b.texto)>0
  and CHARINDEX(a.fmt,b.texto)>0
  
  update a set fmt=substring(fmt,1,charindex('-3 ',fmt)+1) from impactResults a where a.fmt like '%COMP-3 %'
  update a set fmt=substring(fmt,1,charindex('-3.',fmt)+1) from impactResults a where a.fmt like '%COMP-3.%'
  update a set fmt=substring(fmt,1,charindex('COMP ',fmt)+3) from impactResults a where a.fmt like '%COMP %'
  update a set fmt=substring(fmt,1,charindex(' ',fmt)-1) from impactResults a where a.fmt like '% %' and a.fmt not like '% COMP%'
  --update a set fmt=replace(fmt,'  ',' ') from impactResults a where a.fmt like '%  %'
  --while @@ROWCOUNT>0
  --  update a set fmt=replace(fmt,'  ',' ') from impactResults a where a.fmt like '%  %'
  
  update a set altera=replace(replace(fmt,'9(','X('),'V',' ')
              ,dscAlter='Alterar formato num�rico para alfanum�rico' 
    from impactResults a where a.tp=99 and a.altera is null 
  and a.fmt like '9(%'  AND a.txt in ( 'FILIAL', 'NUMBASE', 'CNPJ', 'NUMBASE_BFD', 'BASEFIL', 'CNPJ (BFD)', 'NUMBASE_B_F_D' ) and form IN ( '', '9' )

  update a set altera=replace(replace(fmt,'S9(',' X('),'V',' ') 
              ,dscAlter='Alterar formato num�rico para alfanum�rico' 
    from impactResults a where a.tp=99 and a.altera is null 
  and a.fmt like 'S9(%'  AND a.txt in ( 'FILIAL', 'NUMBASE', 'CNPJ', 'NUMBASE_BFD', 'BASEFIL', 'CNPJ (BFD)', 'NUMBASE_B_F_D' ) and form IN ( '', '9' )
  
  update a set altera=replace(replace(replace(replace(replace(fmt,'S9(',' X('),')V',') '),'9(','X('),' COMP-3','       '),' USAGE','      ') 
              ,dscAlter='Alterar formato num�rico compactado para alfanum�rico' 
    from impactResults a where a.tp=99 and a.altera is null 
  and a.fmt like '%9(%'  AND a.txt in ( 'FILIAL', 'NUMBASE', 'CNPJ', 'NUMBASE_BFD', 'BASEFIL', 'CNPJ (BFD)', 'NUMBASE_B_F_D' ) and form IN ( 'p' )
  
  update a set altera=replace(replace(replace(replace(replace(fmt,'S9(',' X('),')V',') '),'9(','X('),' COMP','     '),' USAGE','      ') 
              ,dscAlter='Alterar formato num�rico bin�rio para alfanum�rico' 
    from impactResults a where a.tp=99 and a.altera is null 
  and a.fmt like '%9(%'  AND a.txt in ( 'FILIAL', 'NUMBASE', 'CNPJ', 'NUMBASE_BFD', 'BASEFIL', 'CNPJ (BFD)', 'NUMBASE_B_F_D' ) and form IN ( 'b' )
  
  update a set altera=replace(replace(fmt,'9','X'),'Z','X') 
              ,dscAlter='Alterar formato num�rico para alfanum�rico' 
    from impactResults a where a.tp=99 and a.altera is null and a.tipo not in ('G','X')
  and a.txt not like '%CPF%'
  and a.txt not like 'DAC'

  update a set altera=replace(c.maskedit,ltrim(str(c.tamanho)), ltrim(str(c.tamanho- 
      ( select sum(expand) from impactResults b where b.programa=a.programa and b.ofs-a.ofs=a.nro1
	     and b.tp=99 and b.tpImpact like 'TAM%'  and b.linexp between a.linexp and a.linate group by ofs ))) )
  , dscalter='Reduzir o tamanho do FILLER para adequar ao aumentos do(s) campos(s) de CNPJ'
  , linpic=c.linhafonte
  ,fmt=c.maskedit
    from impactResults a, TB_VARIAVEIS c where a.tp=97 and a.tamfiller>0 and a.nro2>0 
	 and 1 in ( select top 1 1 from impactResults b where b.programa=a.programa and b.ofs-a.ofs=a.nro1 and b.tp=99 and b.tpImpact like 'TAM%' and b.linexp between a.linexp and a.linate )
	 and tamfiller >= ( select top 1 sum(expand) from impactResults b where b.programa=a.programa and b.ofs-a.ofs=a.nro1 and b.tp=99 and b.tpImpact like 'TAM%'  and b.linexp between a.linexp and a.linate group by ofs)
	 and c.programa=a.programa and c.LINHAEXP=a.linfiller
 
  update a set altera=ltrim(rtrim(replace(altera,'.',''))) from impactResults a where a.altera is not null and altera like '% %'
  update a set altera=ltrim(rtrim(substring(altera,1,charindex(' ',altera)-1))) from impactResults a where a.altera is not null and altera like '% VALUE %'
  
  update a set altera=ltrim(rtrim(altera)) from impactResults a where a.altera is not null and fmt not like 'X%' 
  
  update TB_TEXTO set txtconv=null where txtconv is null
  
  update a set value=b.init from impactResults a, TB_VARIAVEIS b where a.programa=b.PROGRAMA and a.linexp=b.LINHAEXP
  
  update a set linpic=b.LINFONTE from impactResults a, TB_TEXTO b where a.linpic is null and b.fonte=a.fonte and b.LINFONTE=a.linfon
  and CHARINDEX(fmt,texto)>0
  update a set linpic=b.LINFONTE from impactResults a, TB_TEXTO b where a.linpic is null and b.fonte=a.fonte and b.LINFONTE=a.linfon+1
  and CHARINDEX(fmt,texto)>0
  update a set linpic=b.LINFONTE from impactResults a, TB_TEXTO b where a.linpic is null and b.fonte=a.fonte and b.LINFONTE=a.linfon+2
  and CHARINDEX(fmt,texto)>0
  update a set linpic=b.LINFONTE from impactResults a, TB_TEXTO b where a.linpic is null and b.fonte=a.fonte and b.LINFONTE=a.linfon+3
  and CHARINDEX(fmt,texto)>0
  
  update a set linval=b.LINFONTE from impactResults a, TB_TEXTO b where a.linval is null and a.value<>'' and b.fonte=a.fonte and b.LINFONTE=a.linfon
  and CHARINDEX(a.value,texto)>0
  update a set linval=b.LINFONTE from impactResults a, TB_TEXTO b where a.linval is null and a.value<>'' and b.fonte=a.fonte and b.LINFONTE=a.linfon+1
  and CHARINDEX(a.value,texto)>0
  update a set linval=b.LINFONTE from impactResults a, TB_TEXTO b where a.linval is null and a.value<>'' and b.fonte=a.fonte and b.LINFONTE=a.linfon+2
  and CHARINDEX(a.value,texto)>0
  update a set linval=b.LINFONTE from impactResults a, TB_TEXTO b where a.linval is null and a.value<>'' and b.fonte=a.fonte and b.LINFONTE=a.linfon+3
  and CHARINDEX(a.value,texto)>0
  
  update b set txtconv=replace(texto,fmt,altera), tag=txt 
              ,dscAlter=a.dscAlter
    from impactResults a, TB_TEXTO b where a.altera is not null and b.fonte=a.fonte and b.LINFONTE=a.linpic
  and CHARINDEX(fmt,texto)>0

  update b set txtconv=replace(texto,fmt,altera), tag=txt 
              ,dscAlter=a.dscAlter
  -- select * 
    from impactResults a, TB_TEXTO b where a.altera is not null and a.dscalter like '%FILLER%' and b.fonte=a.fonte and b.LINFONTE=a.linpic
     and CHARINDEX(fmt,texto)>0

--  truncate table tb_texto
--SELEct * from impactResults where dscalter like '%FILLER%'
  
  --select a.*  from impactResults a, TB_TEXTO b where a.altera is not null and b.fonte=a.fonte and b.LINFONTE=a.linfon and txtconv is not null
  --and CHARINDEX(fmt,texto)>0
  
  update b set txtconv=replace(texto,fmt,altera), tag=txt 
              ,dscAlter=a.dscAlter
    from impactResults a, TB_TEXTO b where a.altera is not null and b.fonte=a.fonte and b.LINFONTE=a.linfon+1
  and CHARINDEX(fmt,texto)>0
  
  update b set tipo1=replace(replace(c.tipo+c.FORMATO,'99','9'),'XX','X'), tam1=c.TAMANHO
  from impactResults a, TB_varvar b, TB_VARIAVEIS c where a.tp=99 and a.altera is not null
  and b.PROGRAMA=a.programa and b.linvr1=a.linexp
  and c.PROGRAMA=b.PROGRAMA and c.LINHAEXP=linvr1 and c.tipo not in ( '2', 'a' )
  
  update b set tipo2=replace(replace(c.tipo+c.FORMATO,'99','9'),'XX','X'), tam2=c.TAMANHO
  from impactResults a, TB_varvar b, TB_VARIAVEIS c where a.tp=99 and a.altera is not null
  and b.PROGRAMA=a.programa and b.linvr2=a.linexp
  and c.PROGRAMA=b.PROGRAMA and c.LINHAEXP=linvr2 and c.tipo not in ( '2', 'a' )
  
  update a set tipo1=replace(replace(b.tipo+b.FORMATO,'99','9'),'XX','X'), tam1=b.TAMANHO
  from TB_VARVAR a, TB_VARIAVEIS b where tipo2 is not null and tipo1 is null and linvr1>0
  and b.PROGRAMA=a.PROGRAMA and b.LINHAEXP=linvr1 and b.tipo not in ( '2', 'a' )
  
  update a set tipo2=replace(replace(b.tipo+b.FORMATO,'99','9'),'XX','X'), tam2=b.TAMANHO
  from TB_VARVAR a, TB_VARIAVEIS b where tipo1 is not null and tipo2 is null and linvr2>0
  and b.PROGRAMA=a.PROGRAMA and b.LINHAEXP=linvr2 and b.tipo not in ( '2', 'a' )
  
  update a set tipo1='L', tam1=len(vr1) from TB_VARVAR a where tipo2 is not null and tipo1 is null and ISNUMERIC(vr1)=1
  update a set tipo2='L', tam2=len(vr2) from TB_VARVAR a where tipo1 is not null and tipo2 is null and ISNUMERIC(vr2)=1
  
  update a set tipo1='S', tam1=len(vr1)-2 from TB_VARVAR a where tipo2 is not null and tipo1 is null and vr1 like char(39)+'%'+char(39)
  update a set tipo2='S', tam2=len(vr2)-2 from TB_VARVAR a where tipo1 is not null and tipo2 is null and vr2 like char(39)+'%'+char(39)
  
  update a set tipo2='Z', tam2=0 from TB_VARVAR a where a.tipo1 is not null and vr2 in ( 'ZERO', 'ZEROS', 'ZEROES' )
  update a set tipo1='Z', tam1=0 from TB_VARVAR a where a.tipo2 is not null and vr1 in ( 'ZERO', 'ZEROS', 'ZEROES' )
  
  update a set tipo2='N', tam2=0 from TB_VARVAR a where a.tipo1 is not null and vr2 in ( 'NUMERIC' )
  
  update a set tipo2='LOW', tam2=0 from TB_VARVAR a where a.tipo1 is not null and vr2 in ( 'LOW-VALUE', 'LOW-VALUES' )
  update a set tipo2='HIGH', tam2=0 from TB_VARVAR a where a.tipo1 is not null and vr2 in ( 'HIGH-VALUE', 'HIGH-VALUES' )
  update a set tipo2='SPACE', tam2=0 from TB_VARVAR a where a.tipo1 is not null and vr2 in ( 'SPACE', 'SPACES' )
  
  update a set tam1=tam2 from TB_VARVAR a where a.tipo1='S' and item1='ALL'
  
  update a set pic1=maskedit from TB_VARVAR a, TB_VARIAVEIS b where a.tipo1 is not null and a.pic1 is null and b.programa=a.PROGRAMA and b.LINHAEXP=linvr1 and b.MASKEDIT<>''
  update a set pic1='G' from TB_VARVAR a, TB_VARIAVEIS b where a.tipo1 is not null and a.pic1 is null and b.programa=a.PROGRAMA and b.LINHAEXP=linvr1 and b.tipo='G'
  update a set pic2=maskedit from TB_VARVAR a, TB_VARIAVEIS b where a.tipo2 is not null and a.pic2 is null and b.programa=a.PROGRAMA and b.LINHAEXP=linvr2 and b.MASKEDIT<>''
  update a set pic2='G' from TB_VARVAR a, TB_VARIAVEIS b where a.tipo2 is not null and a.pic2 is null and b.programa=a.PROGRAMA and b.LINHAEXP=linvr2 and b.tipo='G'
  
  update a set pic1=pic1+' COMP-3' from TB_VARVAR a where a.tipo1 is not null and a.pic1 is not null and tipo1 like '%p'
  update a set pic1=pic1+' COMP' from TB_VARVAR a where a.tipo1 is not null and a.pic1 is not null and tipo1 like '%b'
  update a set pic2=pic2+' COMP-3' from TB_VARVAR a where a.tipo2 is not null and a.pic2 is not null and tipo2 like '%p'
  update a set pic2=pic2+' COMP' from TB_VARVAR a where a.tipo2 is not null and a.pic2 is not null and tipo2 like '%b'
  
  --select * from impactResults where altera is not null
  
  update a set newpic1=altera from TB_VARVAR a, impactResults b where a.PROGRAMA=b.programa and a.vr1=b.nome and linvr1=b.linexp and b.altera is not null
  update a set newpic2=altera from TB_VARVAR a, impactResults b where a.PROGRAMA=b.programa and a.vr2=b.nome and linvr2=b.linexp and b.altera is not null
  
  update a set newpic1=replace(pic1,'9(','X(') from tb_varvar a where pic1 is not null and newpic1 is null
  update a set newpic2=replace(pic2,'9(','X(') from tb_varvar a where pic2 is not null and newpic2 is null
  
  update a set newpic1= rtrim(substring(newpic1,1,len(newpic1)-1)) from TB_VARVAR a where a.newpic1 is not null  and newpic1 like '%.'
  update a set newpic2= rtrim(substring(newpic2,1,len(newpic2)-1)) from TB_VARVAR a where a.newpic2 is not null  and newpic2 like '%.'
  
  update a set newpic1=substring(newpic1,1,charindex(' VALUE',newpic1)-1) from TB_VARVAR a where a.newpic1 is not null and newpic1 like '% VALUE%'
  update a set newpic1=substring(newpic1,1,charindex(' ALUE',newpic1)-1) from TB_VARVAR a where a.newpic1 is not null and newpic1 like '% ALUE%'
  update a set newpic1=substring(newpic1,1,charindex(' USAGE',newpic1)-1) from TB_VARVAR a where a.newpic1 is not null and newpic1 like '% USAGE%'
  update a set newpic1=substring(newpic1,1,charindex(' COMP',newpic1)-1) from TB_VARVAR a where a.newpic1 is not null and newpic1 like '% COMP%'
  
  update a set newpic2=substring(newpic2,1,charindex(' VALUE',newpic2)-1) from TB_VARVAR a where a.newpic2 is not null and newpic2 like '% VALUE%'
  update a set newpic2=substring(newpic2,1,charindex(' ALUE',newpic2)-1) from TB_VARVAR a where a.newpic2 is not null and newpic2 like '% ALUE%'
  update a set newpic2=substring(newpic2,1,charindex(' USAGE',newpic2)-1) from TB_VARVAR a where a.newpic2 is not null and newpic2 like '% USAGE%'
  update a set newpic2=substring(newpic2,1,charindex(' COMP',newpic2)-1) from TB_VARVAR a where a.newpic2 is not null and newpic2 like '% COMP%'
  
  update a set newpic1=ltrim(rtrim(newpic1)) from tb_varvar a where newpic1 is not null
  update a set newpic2=ltrim(rtrim(newpic2)) from tb_varvar a where newpic2 is not null
  --update a set newpic1=ltrim(rtrim(substring(newpic1,1,charindex(' ',newpic1)-1))) from tb_varvar a where newpic1 is not null and newpic1 like '% %'
  --update a set newpic2=ltrim(rtrim(substring(newpic2,1,charindex(' ',newpic2)-1))) from tb_varvar a where newpic2 is not null and newpic2 like '% %'
  
  update a set pic1=replace(pic1,'(0','(') from tb_varvar a where pic1 is not null
  update a set pic1=replace(pic1,'(0','(') from tb_varvar a where pic1 is not null
  update a set pic2=replace(pic2,'(0','(') from tb_varvar a where pic2 is not null
  update a set pic2=replace(pic2,'(0','(') from tb_varvar a where pic2 is not null
  update a set pic1=pic1+ltrim(str(tam1)) from tb_varvar a where a.pic1='G'
  update a set pic2=pic2+ltrim(str(tam2)) from tb_varvar a where a.pic2='G'
  
  update a set newpic1=replace(newpic1,'(0','(') from tb_varvar a where newpic1 is not null
  update a set newpic1=replace(newpic1,'(0','(') from tb_varvar a where newpic1 is not null
  update a set newpic2=replace(newpic2,'(0','(') from tb_varvar a where newpic2 is not null
  update a set newpic2=replace(newpic2,'(0','(') from tb_varvar a where newpic2 is not null
  
  update a set newpic1=ltrim(replace(newpic1,'SX(','X(')) from tb_varvar a where newpic1 is not null
  update a set newpic1=ltrim(replace(newpic1,')V',')')) from tb_varvar a where newpic1 is not null
  update a set newpic2=ltrim(replace(newpic2,'SX(','X(')) from tb_varvar a where newpic2 is not null
  update a set newpic2=ltrim(replace(newpic2,')V',')')) from tb_varvar a where newpic2 is not null
  
  update a set var1='VAR1-'+replace(replace(pic1,'(','-'),')','-')+(case when tipo1 like '%p' then 'P' when tipo1 like '%b' then 'B' else 'N' end) from TB_VARVAR a where a.pic1 is not null and var1 is null
  update a set var2='VAR2-'+replace(replace(pic2,'(','-'),')','-')+(case when tipo2 like '%p' then 'P' when tipo2 like '%b' then 'B' else 'N' end) from TB_VARVAR a where a.pic2 is not null and var2 is null
  
  update tb_varvar set var1=replace(replace(replace(replace(var1,' ','-'),'--','-'),'.','-'),'/','-') where var1 is not null
  update tb_varvar set var2=replace(replace(replace(replace(var2,' ','-'),'--','-'),'.','-'),'/','-') where var2 is not null
  
  update a set pic2=replace(pic2, 
                 substring(pic2,charindex(')',pic2)-3,4), 
  			   replicate(substring(pic2,charindex(')',pic2)-3,1), substring(pic2,charindex(')',pic2)-2,2)) 
  		) from tb_varvar a where a.pic2 like '%.%)%'
  update a set pic2=replace(pic2, 
                 substring(pic2,charindex(')',pic2)-3,4), 
  			   replicate(substring(pic2,charindex(')',pic2)-3,1), substring(pic2,charindex(')',pic2)-2,2)) 
  		) from tb_varvar a where a.pic2 like '%.%)%'
  update a set pic2=replace(pic2, 
                 substring(pic2,charindex(')',pic2)-3,4), 
  			   replicate(substring(pic2,charindex(')',pic2)-3,1), substring(pic2,charindex(')',pic2)-2,2)) 
  		) from tb_varvar a where a.pic2 like '%.%)%'
  update a set newpic2=replace(newpic2, 
                 substring(newpic2,charindex(')',newpic2)-3,4), 
  			   replicate(substring(newpic2,charindex(')',newpic2)-3,1), substring(newpic2,charindex(')',newpic2)-2,2)) 
  		) from tb_varvar a where a.newpic2 like '%.%)%'
  update a set newpic2=replace(newpic2, 
                 substring(newpic2,charindex(')',newpic2)-3,4), 
  			   replicate(substring(newpic2,charindex(')',newpic2)-3,1), substring(newpic2,charindex(')',newpic2)-2,2)) 
  		) from tb_varvar a where a.newpic2 like '%.%)%'
  update a set newpic2=replace(newpic2, 
                 substring(newpic2,charindex(')',newpic2)-3,4), 
  			   replicate(substring(newpic2,charindex(')',newpic2)-3,1), substring(newpic2,charindex(')',newpic2)-2,2)) 
  		) from tb_varvar a where a.newpic2 like '%.%)%'
  
  update a set actype=
  replace(replace(replace(acao,'>=','GREATER'),'>','GREATER'),'<','LESS')+
  (case when tam1=tam2 then '(=) ' when  tam1>tam2 then '(>) ' else '(<) ' end) +
  tipo1 + ' -> '+ tipo2 
  from TB_VARVAR a where tipo1 is not null and tipo2 is not null
  
  --update a set actype='* '+actype from tb_varvar a where actype is not null and actype not like '* %' and pic1 is not null and pic2 is not null
  --and pic1+pic2 in ( select top 1 pic1+pic2 from tb_varvar b where b.actype=a.actype group by pic1+pic2 order by count(*) desc)
  
  --update a set actype='* '+actype+pic2 from tb_varvar a where pic2 like '%.%' and pic2 not like '%(%'
  
  update a set actimp='MOVEMASK' from tb_varvar a where a.actype like '%MOVE(%)%%' and pic2 like '%.%'
  
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%move(=)%'
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%EQUAL(=)%'
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%LESS(=)%'
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%GREATER(=)%'
  
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%MOVE(<) Z -> 9%'
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%EQUAL(>) 9% -> Z%'
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%GREATER(>) 9% -> Z%'
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%LESS(>) 9% -> Z%'
  
  update a set actimp='NOACT' from tb_varvar a where a.actype like '%MOVE(<) 9% -> X%'
  
  update a set actimp='NUMERIC' from tb_varvar a where a.actype like '%NOT(>)%-> N%'
  update a set actimp='NUMERIC' from tb_varvar a where a.actype like '%IS(>)%-> N%'
  
  update a set actimp='0+STRING' from tb_varvar a where a.actype like '%move(<)%9%9%'
  update a set actimp='0+STRING' from tb_varvar a where a.actype like '%move(<)%X%9%'
  update a set actimp='0+STRING' from tb_varvar a where a.actype like '%move(<)%G%9%'
  
  update a set actimp='(1)SUBSTRING(.)-D' from tb_varvar a where a.actype like '%move(>)%9%9%'
  
  update a set actimp='(1)SUBSTRING-D?' from tb_varvar a where a.actype like '%move(>)%X%9%'
  update a set actimp='(1)SUBSTRING-D?' from tb_varvar a where a.actype like '%move(>)%G%9%'
  update a set actimp='(1)SUBSTRING-DL' from tb_varvar a where a.actype like '%move(>)%L%9%'
  
  update a set actimp='(1)SUBSTRING-E?' from tb_varvar a where a.actype like '%move(>)%9%X%'
  update a set actimp='(1)SUBSTRING-E?' from tb_varvar a where a.actype like '%move(>)%9%G%'
  
  update a set actimp='(1)SUBSTRING(.)-D' from tb_varvar a where a.actype like '%EQUAL(>) 9% -> 9%'
  update a set actimp='(1)SUBSTRING(.)-D' from tb_varvar a where a.actype like '%LESS(>) 9% -> 9%'
  update a set actimp='(1)SUBSTRING(.)-D' from tb_varvar a where a.actype like '%GREATER(>) 9% -> 9%'
  update a set actimp='(2)SUBSTRING(.)-D' from tb_varvar a where a.actype like '%EQUAL(<) 9% -> 9%'
  update a set actimp='(2)SUBSTRING(.)-D' from tb_varvar a where a.actype like '%LESS(<) 9% -> 9%'
  update a set actimp='(2)SUBSTRING(.)-D' from tb_varvar a where a.actype like '%GREATER(<) 9% -> 9%'
  
  update a set actimp='0+L' from tb_varvar a where a.actype like '%EQUAL(>) 9% -> L%'
  update a set actimp='0+L' from tb_varvar a where a.actype like '%LESS(>) 9% -> L%'
  update a set actimp='0+L' from tb_varvar a where a.actype like '%GREATER(>) 9% -> L%'
  
  update a set actimp='MOVE 0+L' from tb_varvar a where a.actype like '%MOVE(<) L -> 9%'
  
  update a set actimp='NOACT' from tb_varvar a where a.actype is not null and item1 like '@%:%' and item2 like '@%:%'
  and cast(substring(item1,charindex(':',item1)+1,255) as int) = cast(substring(item2,charindex(':',item2)+1,255) as int)

  /*  
  select actype, * from tb_varvar a where a.actype is not null and item1 like '@%:%' and item2 like '@%:%'
  and cast(substring(item1,charindex(':',item1)+1,255) as int) <> cast(substring(item2,charindex(':',item2)+1,255) as int)
  
  select actype, * from tb_varvar a where a.actype is not null and item1 like '@%' and item2 like '@%'
  
  select replaCE(ACTYPE,'* ',''), count(*) as qtd, actimp from tb_varvar a where a.actype is not null group by replaCE(ACTYPE,'* ',''), actimp order by 2 desc
  select replaCE(ACTYPE,'* ',''), count(*) as qtd, actimp from tb_varvar a where a.actype is not null and actimp is null group by replaCE(ACTYPE,'* ',''), actimp order by 1 desc
  
  select * from tb_varvar a where a.actype like '%MOVE(<) 9  -> GX%' and actimp is null
  */
  
  --update TB_VARVAR set l1=null, l2=null
  update a set l1=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l1 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+0 and charindex(vr1,b.texto)>0
  update a set l1=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l1 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+1 and charindex(vr1,b.texto)>0
  update a set l1=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l1 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+2 and charindex(vr1,b.texto)>0
  update a set l1=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l1 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+3 and charindex(vr1,b.texto)>0
  update a set l1=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l1 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+4 and charindex(vr1,b.texto)>0
  update a set l1=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l1 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+5 and charindex(vr1,b.texto)>0
  update a set l1=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l1 is null
  and b.fonte=a.FONTE and b.LINFONTE>=a.LINFONTE+0  and b.LINFONTE<(select top 1 linfonte from TB_VARVAR c where c.programa=a.PROGRAMA and c.nrolinha>a.NROLINHA order by nrolinha)
  and charindex(vr1,b.texto)>0
  
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+0 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+1 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+2 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+3 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+4 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+5 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+6 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+7 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+8 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+9 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+10 and charindex(vr2,b.texto)>0
  update a set l2=b.LINFONTE from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l2 is null
  and b.fonte=a.FONTE and b.LINFONTE>=a.LINFONTE+0  and b.LINFONTE<(select top 1 linfonte from TB_VARVAR c where c.programa=a.PROGRAMA and c.nrolinha>a.NROLINHA order by nrolinha)
  and charindex(vr2,b.texto)>0
  
  --select a.vr1, a.texto, b.* from TB_VARVAR a, TB_TEXTO b where a.actimp is not null and l1 is null
  --and b.fonte=a.FONTE and b.LINFONTE=a.LINFONTE+0 
  
  --select * from TB_VARVAR a where a.actimp is not null and l1 is null
  --select * from TB_VARVAR a where a.actimp is not null and l1 is not null
  
  update b set txtconv=b.texto, tag=actimp
  from TB_VARVAR a, TB_TEXTO b where a.actimp='NOACT'
  and b.fonte=a.PROGRAMA and b.LINFONTE in (l1, l2)
  
  update b set txtconv=replicate(' ',charindex('MOVE ',b.texto)-1)+'STRING '+char(39)+replicate('0',tam2-tam1)+char(39)+' ' + vr1+' INTO ' + vr2, tag=actimp
              ,dscAlter='Vari�vel destino maior que vari�vel origem. Concatenar zeros � esquerda da vari�vel origem at� o tamanho da vari�vel destino' 
  from TB_VARVAR a, TB_TEXTO b where a.actimp='0+STRING'
  and b.fonte=a.PROGRAMA and b.LINFONTE=a.LINFONTE
  
  update b set txtconv=replicate(' ',charindex('MOVE ',a.texto)-1)+'MOVE '+vr1+'('+ltrim(str(tam1-tam2+1))+':'+''+ltrim(str(tam2))+')'+' TO ' + vr2, tag=actimp
              ,dscAlter='Vari�vel destino menor que vari�vel origem. Considerar substring � direita da vari�vel origem conforme tamanho da vari�vel destino' 
  from TB_VARVAR a, TB_TEXTO b where actimp='(1)SUBSTRING(.)-D' 
  and b.fonte=a.PROGRAMA and b.LINFONTE=a.LINFONTE and tag is null

  update b set txtconv=replace(b.texto,vr2, vr2+'('+ltrim(str(tam2-tam1+1))+':'+''+ltrim(str(tam1))+')'), tag=actimp
              ,dscAlter='Compara��o de vari�veis de tamanhos diferentes. Considerar substring da vari�vel maior conforme tamanho da vari�vel menor' 
  from TB_VARVAR a, TB_TEXTO b where actimp='(2)SUBSTRING(.)-D' 
  and b.fonte=a.PROGRAMA and b.LINFONTE=l2 and tag is null
  
  update b set txtconv=replace(b.texto,' NUMERIC',' CNPJVALID'), tag=actimp
              ,dscAlter='Substituir o tratamento NUMERIC pela classe CNPJVALID definida na cl�usula SPECIAL NAMES' 
  from TB_VARVAR a, TB_TEXTO b where a.actimp='NUMERIC'
  and b.fonte=a.PROGRAMA and b.LINFONTE=l2 and tag is null
  
  update b set txtconv=replace(b.texto+' ',' '+vr2+' ',' '+char(39)+replicate('0',tam1-len(vr2))+vr2+char(39)+' '), tag=actimp
              ,dscAlter='Compara��o com literal de tamanho menor. Complementar com zeros � esquerda da literal conforme tamanho da vari�vel menor' 
  from TB_VARVAR a, TB_TEXTO b where a.actimp='0+L'
  and b.fonte=a.PROGRAMA and b.LINFONTE in (l2,a.LINFONTE) and tag is null and isnumeric(vr2)=1 
  and CHARINDEX(' '+vr2+' ',b.texto+' ')>0
  
  update b set txtconv=replace(b.texto+' ',' '+vr1+' ',' '+char(39)+replicate('0',tam2-len(vr1))+vr1+char(39)+' '), tag=actimp
              ,dscAlter='Movimenta��o de literal de tamanho menor. Complementar com zeros � esquerda da literal conforme tamanho da vari�vel destino' 
  from TB_VARVAR a, TB_TEXTO b where a.actimp='MOVE 0+L'
  and b.fonte=a.PROGRAMA and b.LINFONTE in (l1) and tag is null and isnumeric(vr1)=1 
  and CHARINDEX(' '+vr1+' ',b.texto+' ')>0
  
  update b set dtgen=getdate() from TB_TEXTO a, impactCatalog b where txtconv is not null and dscalter is not null
  and a.fonte=b.nome

end
--go  

--exec iMappAlterar
--select * from TB_TEXTO where txtconv is not null
