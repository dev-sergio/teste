--alter table tb_variaveis add prox int
--alter table tb_variaveis add ant int
--alter table tb_variaveis add lincmt int

update a set prox=(select min(linhaexp) from TB_VARIAVEIS b where b.programa=a.PROGRAMA and b.LINHAEXP>a.LINHAEXP) from TB_VARIAVEIS a
update a set prox=99999 from TB_VARIAVEIS a where prox is null

update a set ant=(select max(linhaexp) from TB_VARIAVEIS b where b.programa=a.PROGRAMA and b.LINHAEXP<a.LINHAEXP) from TB_VARIAVEIS a
update a set ant=0 from TB_VARIAVEIS a where ant is null

select a.fonte, a.linhafonte, a.nome, b.* from TB_VARIAVEIS a, TB_COMMENT b where a.programa<>a.fonte and b.fonte=a.fonte and b.EXT<>'CBL' 
--and b.LINFONTE>a.LINHAFONTE
and b.LINFONTE=
(select top 1 linfonte from TB_COMMENT x where x.fonte=a.fonte and ext<>'CBL' and x.LINFONTE>a.LINHAFONTE order by LINFONTE)

select a.nome, b.* from TB_VARIAVEIS a, TB_COMMENT b where a.fonte=b.fonte and b.LINFONTE=a.LINHAFONTE-1
SELECT * FROM TB_COMMENT WHERE EXT='CPY'

select * from impactResults where nome='TSBL40-QTDEOCOR-N'
select * from TABIMPACT where objeto='TSBL40-QTDEOCOR-N'
select * from TABIMPACT where seq=876

select distinct fonte, linfon, min(linexp) as linexp from impactResults where programa='BPX99C' group by fonte, linfon order by 3

select * from impactResults
select * from tb_varvar where fonte='BPX99C' and 

